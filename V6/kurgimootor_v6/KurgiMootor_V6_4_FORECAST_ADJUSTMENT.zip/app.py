from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo
from pathlib import Path
import math

from PIL import Image

import numpy as np
import pandas as pd
import streamlit as st
import streamlit.components.v1 as components

import db
from core import WeatherService

TODAY = datetime.now(ZoneInfo("Europe/Tallinn")).date()
APP_ICON_PATH = Path(__file__).resolve().parent / "assets" / "kurgimootor_icon.png"
APP_ICON = Image.open(APP_ICON_PATH)
st.set_page_config(page_title="KurgiMootor V6.4", page_icon=APP_ICON, layout="wide")

# PWA / iOS Home Screen metadata. Streamlit does not expose <head> directly,
# so a tiny same-origin component appends the standard tags to the parent page.
components.html(
    """
    <script>
    (() => {
      const doc = window.parent.document;

      function ensureLink(rel, href, attrs = {}) {
        let el = doc.head.querySelector(`link[rel="${rel}"]`);
        if (!el) {
          el = doc.createElement("link");
          el.rel = rel;
          doc.head.appendChild(el);
        }
        el.href = href;
        Object.entries(attrs).forEach(([k, v]) => el.setAttribute(k, v));
      }

      function ensureMeta(name, content, byProperty = false) {
        const attr = byProperty ? "property" : "name";
        let el = doc.head.querySelector(`meta[${attr}="${name}"]`);
        if (!el) {
          el = doc.createElement("meta");
          el.setAttribute(attr, name);
          doc.head.appendChild(el);
        }
        el.setAttribute("content", content);
      }

      ensureLink("manifest", "/app/static/manifest.webmanifest");
      ensureLink("apple-touch-icon", "/app/static/apple-touch-icon.png", {"sizes": "180x180"});
      ensureLink("icon", "/app/static/kurgimootor-192.png", {"type": "image/png", "sizes": "192x192"});

      ensureMeta("theme-color", "#0b3b24");
      ensureMeta("mobile-web-app-capable", "yes");
      ensureMeta("apple-mobile-web-app-capable", "yes");
      ensureMeta("apple-mobile-web-app-status-bar-style", "black-translucent");
      ensureMeta("apple-mobile-web-app-title", "KurgiMootor");

      doc.title = "KurgiMootor";
    })();
    </script>
    """,
    height=0,
    width=0,
)



def _n(value) -> float:
    try:
        return float(value or 0)
    except (TypeError, ValueError):
        return 0.0


def _fmt(value: float, digits: int = 1) -> str:
    return f"{value:.{digits}f}".replace(".", ",")


def _temperature_curve_features(tmins, tmaxs):
    """Literature-informed, data-fitted nonlinear cucumber temperature basis.

    Breakpoints encode only where physiology plausibly changes regime.
    The coefficients/strength are learned from this farm's harvest data.

    Night:
      <16 C  : cold deficit + squared cold deficit (curvature; 12 can hurt far more than 14)
      16-20 C: warm-night band
      >20 C  : hot-night excess

    Day:
      <20 C  : cool-day deficit + squared deficit
      20-28 C: productive warm band
      >30 C  : heat excess + squared heat excess

    Values are interval means so harvest interval length remains a separate feature.
    """
    tmins = np.asarray(list(tmins), dtype=float)
    tmaxs = np.asarray(list(tmaxs), dtype=float)
    if len(tmins) == 0 or len(tmaxs) == 0:
        return {}

    night_cold = np.maximum(0.0, 16.0 - tmins)
    night_warm = np.clip(tmins - 16.0, 0.0, 4.0)
    night_hot = np.maximum(0.0, tmins - 20.0)

    day_cool = np.maximum(0.0, 20.0 - tmaxs)
    day_warm = np.clip(tmaxs - 20.0, 0.0, 8.0)
    day_hot = np.maximum(0.0, tmaxs - 30.0)

    return {
        "Öö jahedus <16": float(np.mean(night_cold)),
        "Öö jahedus² <16": float(np.mean(night_cold ** 2)),
        "Öö soojus 16-20": float(np.mean(night_warm)),
        "Öö kuumus >20": float(np.mean(night_hot)),
        "Päeva jahedus <20": float(np.mean(day_cool)),
        "Päeva jahedus² <20": float(np.mean(day_cool ** 2)),
        "Päeva soojus 20-28": float(np.mean(day_warm)),
        "Päeva kuumus >30": float(np.mean(day_hot)),
        "Päeva kuumus² >30": float(np.mean(day_hot ** 2)),
    }




# Astronoomiline päevapikkus Pärnu piirkonna laiuskraadil.
# Longitude pole päevapikkuse kestuse jaoks vajalik; kasutame geograafilist laiust ~58.38 N.
DAYLENGTH_LAT = 58.38

def _daylength_hours(day_value):
    n = int(day_value.timetuple().tm_yday)
    lat = math.radians(DAYLENGTH_LAT)
    # NOAA-tüüpi lihtsustatud päikesedeklinatsioon; piisav fotoperioodi tunnuseks.
    decl = math.radians(23.44) * math.sin(2.0 * math.pi * (284 + n) / 365.0)
    cos_omega = -math.tan(lat) * math.tan(decl)
    cos_omega = max(-1.0, min(1.0, cos_omega))
    omega = math.acos(cos_omega)
    return 24.0 * omega / math.pi

def _daylength_change_7d(day_value):
    return _daylength_hours(day_value) - _daylength_hours(day_value - timedelta(days=7))

def _format_field_value(value, digits=1):
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return "—"
    try:
        return _fmt(float(value), digits)
    except (TypeError, ValueError):
        return str(value)

def _short_date(value: date) -> str:
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    return f"{value.day:02d}. {months[value.month - 1]}"


def _weekday_letter(value: date) -> str:
    return ["E", "T", "K", "N", "R", "L", "P"][value.weekday()]


def _daily_summary(rows):
    count = len(rows)
    a = sum(_n(r.get("a")) for r in rows)
    b = sum(_n(r.get("b")) for r in rows)
    c = sum(_n(r.get("c")) for r in rows)
    xl = sum(_n(r.get("xl")) for r in rows)
    total = sum(_n(r.get("total")) for r in rows)
    cb = c / b if b > 0 else None
    return {
        "count": count,
        "a": a,
        "b": b,
        "c": c,
        "xl": xl,
        "total": total,
        "cb": cb,
    }


def _next_field(field_no: int) -> int:
    return 1 if field_no >= 14 else field_no + 1


def _planned_fields_for_day(day: date, today_rows, history_rows):
    # Kui tänasest on vähemalt üks õige korje sisestatud, kasutame päeva esimese
    # korje põldu ploki algusena. Nii jääb plaan kooskõlla päriselt sisestatud andmetega.
    ordered_today = sorted(today_rows, key=lambda r: int(r.get("harvest_order") or 99))
    if ordered_today:
        first = int(ordered_today[0].get("field_no"))
        return [first, _next_field(first), _next_field(_next_field(first))]

    # Muidu võtame viimase varasema päeva viimase korjepõllu ja liigume sealt edasi.
    previous = []
    for r in history_rows:
        try:
            rday = date.fromisoformat(str(r.get("harvest_date")))
        except (TypeError, ValueError):
            continue
        if rday < day:
            previous.append(r)

    if previous:
        latest_day = max(date.fromisoformat(str(r.get("harvest_date"))) for r in previous)
        latest_rows = [r for r in previous if str(r.get("harvest_date")) == latest_day.isoformat()]
        latest_rows.sort(key=lambda r: int(r.get("harvest_order") or 99))
        last_field = int(latest_rows[-1].get("field_no"))
        first = _next_field(last_field)
        return [first, _next_field(first), _next_field(_next_field(first))]

    return [1, 2, 3]


def _field_table(rows, planned_fields=None):
    by_field = {int(r.get("field_no")): r for r in rows if r.get("field_no") is not None}
    fields = planned_fields or [int(r.get("field_no")) for r in rows if r.get("field_no") is not None]
    table = []
    missing_rows = set()

    for field_no in fields:
        r = by_field.get(int(field_no))
        if r is None:
            missing_rows.add(len(table))
            table.append({
                "Põld": int(field_no),
                "A": None,
                "B": None,
                "C": None,
                "XL": None,
                "Kokku": "Andmed puuduvad",
                "C/B": None,
            })
            continue

        b = _n(r.get("b"))
        c = _n(r.get("c"))
        table.append({
            "Põld": r.get("field_no"),
            "A": _n(r.get("a")),
            "B": b,
            "C": c,
            "XL": _n(r.get("xl")),
            "Kokku": _n(r.get("total")),
            "C/B": round(c / b, 2) if b > 0 else None,
        })

    # Kui mingil põhjusel on sisestatud põld, mida plaanis polnud, näitame ka selle välja.
    planned_set = {int(f) for f in fields}
    for field_no, r in by_field.items():
        if field_no in planned_set:
            continue
        b = _n(r.get("b"))
        c = _n(r.get("c"))
        table.append({
            "Põld": field_no,
            "A": _n(r.get("a")),
            "B": b,
            "C": c,
            "XL": _n(r.get("xl")),
            "Kokku": _n(r.get("total")),
            "C/B": round(c / b, 2) if b > 0 else None,
        })

    return pd.DataFrame(table), missing_rows


def _render_day_block(day_label, rows, show_quality=False, planned_fields=None):
    s = _daily_summary(rows)
    cb_text = "—" if s["cb"] is None else _fmt(s["cb"], 2)
    st.markdown(f"### {day_label}\u2003\u2003{_fmt(s['total'])} kasti")
    st.caption(
        f"A {_fmt(s['a'])} · B {_fmt(s['b'])} · C {_fmt(s['c'])} · "
        f"XL {_fmt(s['xl'])} · C/B {cb_text} · {s['count']}/3 põldu"
    )

    df, missing_rows = _field_table(rows, planned_fields=planned_fields)

    formatters = {
        "A": lambda v: _format_field_value(v, 1),
        "B": lambda v: _format_field_value(v, 1),
        "C": lambda v: _format_field_value(v, 1),
        "XL": lambda v: _format_field_value(v, 1),
        "Kokku": lambda v: _format_field_value(v, 1),
        "C/B": lambda v: _format_field_value(v, 2),
    }
    styled = df.style.format(formatters)

    if missing_rows:
        def _highlight_missing(row):
            if row.name in missing_rows:
                return ["background-color: rgba(255, 193, 7, 0.28)" for _ in row]
            return ["" for _ in row]
        styled = styled.apply(_highlight_missing, axis=1)
        st.dataframe(styled, use_container_width=True, hide_index=True)
        st.caption("Kollane = tänase põllu korjeandmed on veel puudu.")
    else:
        st.dataframe(styled, use_container_width=True, hide_index=True)

    if show_quality:
        notes = []
        for r in rows:
            quality = r.get("data_quality") or ""
            note = r.get("note") or ""
            if quality or note:
                notes.append({"Põld": r.get("field_no"), "Andmekvaliteet": quality, "Märkus": note})
        if notes:
            with st.expander("Andmekvaliteet ja märkused"):
                st.dataframe(pd.DataFrame(notes), use_container_width=True, hide_index=True)


# Ilm kontrollitakse automaatselt üks kord päevas. Viga ei takista korjete kasutamist.
try:
    WeatherService().auto_refresh_if_needed(TODAY)
except Exception as exc:
    db.set_app_setting("weather_last_error", f"Automaatne ilmauuendus: {exc}")

st.title("KurgiMootor V6.4")
st.caption("Saagi ennustamise tööriist. Avaleht on töövoog, mitte ilmarakendus.")

tabs = st.tabs(["Täna", "Korjed", "Ilm", "Prognoos", "Mootori tähelepanekud"])

with tabs[0]:
    today_rows = db.get_harvest_for_day(TODAY)
    harvest_history_for_plan = db.get_harvest_history()
    today_planned_fields = _planned_fields_for_day(TODAY, today_rows, harvest_history_for_plan)

    # Päeva vahetudes lähtestame tänase plaani automaatselt.
    current_home_day = TODAY.isoformat()
    if st.session_state.get("home_plan_day") != current_home_day:
        st.session_state["home_plan_day"] = current_home_day
        st.session_state["home_today_fields"] = list(today_planned_fields)

    # Turvavõrk: kui sessionis on tühi/puuduv valik ilma kasutaja teadliku muutmiseta,
    # alustame tänase automaatse plaaniga.
    if "home_today_fields" not in st.session_state:
        st.session_state["home_today_fields"] = list(today_planned_fields)

    selected_today_fields = st.multiselect(
        "Täna korjatavad põllud",
        options=list(range(1, 15)),
        key="home_today_fields",
        max_selections=4,
        help="Muuda ainult tänase tööplaani. Saagi sisestamine käib Korjed-menüüs.",
    )

    if selected_today_fields:
        if len(selected_today_fields) >= 2:
            fields_text = ", ".join(str(f) for f in selected_today_fields[:-1]) + f" ja {selected_today_fields[-1]}"
        else:
            fields_text = str(selected_today_fields[0])
        plan_text = f"Täna korjatakse põllud nr {fields_text}"
    else:
        plan_text = "Täna korjet ei ole"

    st.markdown(
        f"""
        <div style="display:flex;align-items:baseline;gap:10px;margin-bottom:4px;">
          <span style="font-size:2.0rem;font-weight:950;opacity:.35;">{_weekday_letter(TODAY)}</span>
          <span style="font-size:2.15rem;font-weight:900;line-height:1.05;">{_short_date(TODAY)}</span>
        </div>
        <div style="font-size:1.10rem;font-weight:650;opacity:.82;margin-bottom:10px;">{plan_text}</div>
        """,
        unsafe_allow_html=True,
    )

    today_top_left, today_top_right = st.columns(2, gap="large")
    with today_top_left:
        home_today_actual_slot = st.empty()
    with today_top_right:
        home_today_forecast_slot = st.empty()

    st.markdown("#### Tänased põllud")
    today_by_field = {int(r.get("field_no")): r for r in today_rows if r.get("field_no") is not None}

    if not selected_today_fields:
        st.info("Täna korjet ei ole.")
    else:
        for field_no in selected_today_fields:
            row = today_by_field.get(int(field_no))
            if row:
                b = _n(row.get("b"))
                c = _n(row.get("c"))
                cb = c / b if b > 0 else None
                cb_text = "—" if cb is None else _fmt(cb, 2)
                total = _n(row.get("total"))
                st.markdown(
                    f"""
                    <div style="background:rgba(40,167,69,.10);border:1px solid rgba(40,167,69,.38);
                                border-radius:10px;padding:9px 11px;margin:5px 0;">
                      <div style="display:flex;justify-content:space-between;gap:10px;align-items:baseline;">
                        <strong>Põld {int(field_no)}</strong>
                        <strong>{_fmt(total)} kasti</strong>
                      </div>
                      <div style="font-size:.92rem;opacity:.78;margin-top:3px;">
                        A {_fmt(_n(row.get('a')))} · B {_fmt(b)} · C {_fmt(c)} · XL {_fmt(_n(row.get('xl')))} · C/B {cb_text}
                      </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
            else:
                st.markdown(
                    f"""
                    <div style="background:#fff3cd;border:1px solid #ffe69c;
                                border-radius:10px;padding:9px 11px;margin:5px 0;">
                      <div style="display:flex;justify-content:space-between;gap:10px;align-items:baseline;">
                        <strong>Põld {int(field_no)}</strong>
                        <strong>korje sisestamata</strong>
                      </div>
                      <div style="font-size:.92rem;opacity:.72;margin-top:3px;">
                        A — · B — · C — · XL — · C/B —
                      </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

    st.markdown("#### Mootori info")
    home_engine_info_slot = st.empty()

    st.divider()
    st.markdown("#### Järgmised päevad")
    home_future_forecast_slot = st.empty()

with tabs[1]:
    st.subheader("Korjed")
    st.caption("Andmebaasis hoitakse iga põllu korje eraldi. Äpis vaatame saaki eelkõige päevade kaupa.")

    # Järgmise korje vaikimisi valikud tuletatakse esmalt päris tänastest andmetest.
    # Nii avaneb äpp pärast refreshi/redeploy'd kohe järgmise puuduva põllu ja järjekorraga,
    # mitte ei kuku tagasi 1 / 1 peale. Session state jääb siiski sama sessiooni jooksul
    # pärast salvestust esmaseks, et järgmisele reale liikumine oleks kohene.
    today_rows_for_form = db.get_harvest_for_day(TODAY)
    history_for_form = db.get_harvest_history()
    planned_for_form = _planned_fields_for_day(TODAY, today_rows_for_form, history_for_form)

    used_orders = {
        int(r.get("harvest_order"))
        for r in today_rows_for_form
        if r.get("harvest_order") is not None and int(r.get("harvest_order")) in (1, 2, 3)
    }
    missing_orders = [order for order in (1, 2, 3) if order not in used_orders]

    if missing_orders:
        inferred_order = missing_orders[0]
        inferred_field = int(planned_for_form[inferred_order - 1])
    elif today_rows_for_form:
        # Päev on 3/3 valmis. Kui kasutaja siiski lisab/parandab uut rida,
        # alustame järgmisest põllust ja järjekorrast 1.
        ordered_complete = sorted(today_rows_for_form, key=lambda r: int(r.get("harvest_order") or 99))
        inferred_field = _next_field(int(ordered_complete[-1].get("field_no")))
        inferred_order = 1
    else:
        inferred_field = int(planned_for_form[0])
        inferred_order = 1

    default_field = int(st.session_state.get("next_harvest_field", inferred_field))
    default_order = int(st.session_state.get("next_harvest_order", inferred_order))
    form_version = int(st.session_state.get("harvest_form_version", 0))

    st.markdown("#### Lisa või paranda korje")
    if st.session_state.get("harvest_saved_message"):
        st.success(st.session_state.pop("harvest_saved_message"))
    with st.form("manual_harvest_form"):
        c1, c2, c3 = st.columns(3)
        entry_date = c1.date_input("Kuupäev", value=TODAY, key="manual_harvest_date")
        entry_field = c2.selectbox(
            "Põld",
            list(range(1, 15)),
            index=max(0, min(13, default_field - 1)),
            key=f"manual_harvest_field_{form_version}",
        )
        entry_order = c3.selectbox(
            "Järjekord",
            [1, 2, 3],
            index=max(0, min(2, default_order - 1)),
            key=f"manual_harvest_order_{form_version}",
        )
        q1, q2, q3, q4 = st.columns(4)
        entry_a_raw = q1.number_input(
            "A", min_value=0.0, value=None, step=0.1, format="%.1f",
            placeholder="0,0", key=f"manual_a_{form_version}"
        )
        entry_b_raw = q2.number_input(
            "B", min_value=0.0, value=None, step=0.1, format="%.1f",
            placeholder="0,0", key=f"manual_b_{form_version}"
        )
        entry_c_raw = q3.number_input(
            "C", min_value=0.0, value=None, step=0.1, format="%.1f",
            placeholder="0,0", key=f"manual_c_{form_version}"
        )
        entry_xl_raw = q4.number_input(
            "XL", min_value=0.0, value=None, step=0.1, format="%.1f",
            placeholder="0,0", key=f"manual_xl_{form_version}"
        )

        # Tühi väli tähendab 0, kuid kasutaja ei pea telefonis nulli kustutama.
        entry_a = float(entry_a_raw or 0.0)
        entry_b = float(entry_b_raw or 0.0)
        entry_c = float(entry_c_raw or 0.0)
        entry_xl = float(entry_xl_raw or 0.0)

        total_preview = entry_a + entry_b + entry_c + entry_xl
        cb_preview = entry_c / entry_b if entry_b > 0 else None
        preview_text = f"Kokku: {_fmt(total_preview)}"
        if cb_preview is not None:
            preview_text += f" · C/B: {_fmt(cb_preview, 2)}"
        st.caption(preview_text)

        if st.form_submit_button("Salvesta korje"):
            if total_preview <= 0:
                st.warning("Korje kogus on 0. Sisesta vähemalt üks kogus.")
            else:
                db.save_harvest(
                    entry_date,
                    entry_field,
                    0,
                    entry_a,
                    entry_b,
                    entry_c,
                    entry_xl,
                    harvest_order=entry_order,
                )

                # Järgmise rea loogika: põld edasi, 14 järel 1; järjekord 1→2→3→1.
                st.session_state["next_harvest_field"] = 1 if entry_field >= 14 else entry_field + 1
                st.session_state["next_harvest_order"] = 1 if entry_order >= 3 else entry_order + 1

                # Uus vormiversioon sunnib Streamliti looma värsked väljad.
                # Nii avaneb järgmine rida päriselt järgmise põllu/järjekorraga ja A/B/C/XL = 0.
                st.session_state["harvest_form_version"] = form_version + 1
                st.session_state["harvest_saved_message"] = (
                    f"Salvestatud: {entry_date} · põld {entry_field} · kokku {_fmt(total_preview)}"
                )
                st.rerun()

    st.divider()
    st.markdown("#### Korjeajalugu päevade kaupa")
    rows = db.get_harvest_history()
    if rows:
        by_day = {}
        for row in rows:
            by_day.setdefault(str(row.get("harvest_date")), []).append(row)

        for day_str, day_rows in by_day.items():
            try:
                day_date = date.fromisoformat(day_str)
                day_label = _short_date(day_date)
            except ValueError:
                day_date = None
                day_label = day_str

            planned_fields = None
            if day_date == TODAY:
                planned_fields = _planned_fields_for_day(TODAY, day_rows, rows)

            _render_day_block(day_label, day_rows, show_quality=True, planned_fields=planned_fields)
            st.divider()

        with st.expander("Näita kõiki korjeridu ühe tabelina"):
            df = pd.DataFrame(rows).rename(columns={
                "harvest_date": "Kuupäev",
                "field_no": "Põld",
                "harvest_order": "Järjekord",
                "interval_days": "Intervall",
                "a": "A",
                "b": "B",
                "c": "C",
                "xl": "XL",
                "total": "Kokku",
                "data_quality": "Andmekvaliteet",
                "note": "Märkus",
            })
            if not df.empty and "B" in df.columns and "C" in df.columns:
                df["C/B"] = df.apply(lambda r: round(_n(r["C"]) / _n(r["B"]), 2) if _n(r["B"]) > 0 else None, axis=1)
            all_rows_formatters = {
                "A": lambda v: _format_field_value(v, 1),
                "B": lambda v: _format_field_value(v, 1),
                "C": lambda v: _format_field_value(v, 1),
                "XL": lambda v: _format_field_value(v, 1),
                "Kokku": lambda v: _format_field_value(v, 1),
                "C/B": lambda v: _format_field_value(v, 2),
            }
            st.dataframe(df.style.format(all_rows_formatters), use_container_width=True, hide_index=True)
    else:
        st.info("Korjeid pole veel sisestatud.")

with tabs[2]:
    st.subheader("Ilmaklots")
    st.caption("Mõõdetud temperatuur, tuul, globaalradiatsioon, õhuniiskus ja sademed Pärnu jaamast. ET0 arvutatakse automaatselt.")
    counts = db.get_weather_counts()
    a, b, c = st.columns(3)
    a.metric("Mõõdetud päevi", counts["measured"])
    b.metric("Rohelisi päevi", counts["checked"])
    c.metric("Prognoosipäevi", counts["forecast"])
    st.caption(f"Viimane automaatne uuendus: {db.get_app_setting('weather_last_refresh_at', '—')}")
    last_result = db.get_app_setting("weather_last_result", "")
    if last_result:
        st.caption(last_result)
    error = db.get_app_setting("weather_last_error", "")
    if error:
        st.error(error)
    if st.button("Uuenda ilm kohe"):
        with st.spinner("Laen mõõteandmeid ja 9 päeva prognoosi..."):
            result = WeatherService().safe_refresh_all(TODAY)
        if result.get("error"):
            st.warning(f"Uuendus tehti osaliselt: {result['error']}")
        else:
            st.success("Ilmaandmed uuendatud.")
        st.rerun()

    if st.button("Kontrolli Pärnu allikaid"):
        with st.spinner("Kontrollin Pärnu viimase lõppenud päeva tunni- ja päevaandmeid..."):
            try:
                source_test = WeatherService().test_sources(TODAY)
                st.caption(
                    f"Kontrollpäev {source_test.get('measured_day', '—')} · "
                    f"TA {source_test.get('parnu_temperature_rows', 0)} · "
                    f"WS10M {source_test.get('parnu_wind_rows', 0)} · "
                    f"RH {source_test.get('parnu_rh_hourly_rows', 0)} · "
                    f"PR1H {source_test.get('parnu_pr1h_hourly_rows', 0)} · "
                    f"SDUR1H {source_test.get('parnu_sdur1h_hourly_rows', 0)} rida"
                )
                st.caption(
                    f"Päevaelemendid: DRQS {source_test.get('parnu_radiation_rows', 0)} · "
                    f"DRH08 {source_test.get('parnu_humidity_rows', 0)} · "
                    f"DPREC {source_test.get('parnu_precipitation_rows', 0)} · "
                    f"ET0 {source_test.get('et0_mm', None)}"
                )
            except Exception as exc:
                st.error(f"Pärnu allikate kontroll ebaõnnestus: {exc}")

    history_default_start = date(TODAY.year, 7, 1)
    history_default_end = TODAY
    st.subheader("Mõõdetud ilma ajalugu")
    d1, d2 = st.columns(2)
    history_start = d1.date_input(
        "Alguskuupäev",
        value=history_default_start,
        max_value=TODAY,
        key="weather_history_start",
    )
    history_end = d2.date_input(
        "Lõppkuupäev",
        value=history_default_end,
        max_value=TODAY,
        key="weather_history_end",
    )
    if history_start > history_end:
        st.warning("Alguskuupäev peab olema lõppkuupäevast varasem.")
        measured_rows = []
    else:
        history_rows = db.get_weather_rows(history_start, history_end)
        measured_rows = [r for r in history_rows if r.get("data_kind") == "measured"][::-1]

    forecast_rows = [
        r for r in db.get_weather_rows(TODAY, TODAY + timedelta(days=8))
        if r.get("data_kind") == "forecast"
    ]

    st.caption(
        f"Kuvatakse {len(measured_rows)} päeva. 🟢 = täielikult mõõdetud; "
        "🟡 = puuduv mõõdetud väärtus on tabelis ja mudelis ajutiselt täidetud kuni 3 varasema päeva keskmisega. "
        "Andmebaasi mõõdetud rida selle tõttu ei muudeta."
    )

    weather_columns = [
        "temp_min_c", "temp_max_c", "wind_avg_ms", "humidity_avg_pct",
        "precipitation_mm", "et0_mm", "radiation_mj_m2",
    ]

    # Vajame fallbackiks ka kuni 3 päeva enne valitud ajaloo algust.
    fallback_start = history_start - timedelta(days=3)
    fallback_rows = db.get_weather_rows(fallback_start, history_end)
    fallback_by_day = {
        str(r.get("weather_date")): r
        for r in fallback_rows
        if r.get("data_kind") == "measured"
    }

    def _history_effective_value(day_value, feature):
        """Tagastab (väärtus, kas_hinnanguline) ainult tabeli/mudeli töövaate jaoks."""
        row = fallback_by_day.get(day_value.isoformat()) or {}
        raw = row.get(feature)
        try:
            if raw is not None:
                return float(raw), False
        except (TypeError, ValueError):
            pass

        prior = []
        for delta in range(1, 4):
            prev = fallback_by_day.get((day_value - timedelta(days=delta)).isoformat()) or {}
            val = prev.get(feature)
            try:
                if val is not None:
                    prior.append(float(val))
            except (TypeError, ValueError):
                pass

        if prior:
            return float(np.mean(prior)), True
        return None, False

    measured_display = []
    estimated_display_cells = set()

    for idx, r in enumerate(measured_rows):
        try:
            row_day = date.fromisoformat(str(r.get("weather_date")))
        except ValueError:
            row_day = None

        effective = {}
        estimated_features = []
        display_col_by_feature = {
            "temp_min_c": "Min °C",
            "temp_max_c": "Max °C",
            "wind_avg_ms": "Tuul m/s",
            "humidity_avg_pct": "Niiskus %",
            "precipitation_mm": "Sademed mm",
            "et0_mm": "ET0 mm",
            "radiation_mj_m2": "Radiatsioon MJ/m²",
        }

        for feature in weather_columns:
            if row_day is None:
                effective[feature] = r.get(feature)
                continue
            value, estimated = _history_effective_value(row_day, feature)
            effective[feature] = value
            if estimated:
                estimated_features.append(feature)
                estimated_display_cells.add((idx, display_col_by_feature[feature]))

        if estimated_features:
            status = "🟡 Osaliselt hinnanguline"
            estimated_names = [display_col_by_feature[f] for f in estimated_features]
            control = "Hinnanguline: " + ", ".join(estimated_names)
        elif r.get("checked"):
            status = "🟢 Kontrollitud"
            control = r.get("check_message")
        else:
            status = "🔴 Puudulik"
            control = r.get("check_message")

        measured_display.append({
            "Kuupäev": r["weather_date"],
            "Min °C": effective.get("temp_min_c"),
            "Max °C": effective.get("temp_max_c"),
            "Tuul m/s": effective.get("wind_avg_ms"),
            "Niiskus %": effective.get("humidity_avg_pct"),
            "Sademed mm": effective.get("precipitation_mm"),
            "ET0 mm": effective.get("et0_mm"),
            "Radiatsioon MJ/m²": effective.get("radiation_mj_m2"),
            "Kontroll": control,
            "Olek": status,
        })

    measured_df = pd.DataFrame(measured_display)
    if not measured_df.empty:
        styled_weather = measured_df.style

        def _highlight_estimated_cells(data):
            styles = pd.DataFrame("", index=data.index, columns=data.columns)
            for row_idx, col_name in estimated_display_cells:
                if row_idx in styles.index and col_name in styles.columns:
                    styles.loc[row_idx, col_name] = "background-color: rgba(255, 193, 7, 0.30)"
            # Olek jääb kollaseks, kui päevas on vähemalt üks hinnanguline lahter.
            estimated_rows = {r for r, _ in estimated_display_cells}
            for row_idx in estimated_rows:
                if row_idx in styles.index and "Olek" in styles.columns:
                    styles.loc[row_idx, "Olek"] = "background-color: rgba(255, 193, 7, 0.20)"
            return styles

        styled_weather = styled_weather.apply(_highlight_estimated_cells, axis=None)

        # Ainult kuvamisvorming; arvutustes jäävad täpsed väärtused alles.
        styled_weather = styled_weather.format({
            "Min °C": "{:.1f}",
            "Max °C": "{:.1f}",
            "Tuul m/s": "{:.2f}",
            "Niiskus %": "{:.0f}",
            "Sademed mm": "{:.1f}",
            "ET0 mm": "{:.2f}",
            "Radiatsioon MJ/m²": "{:.2f}",
        }, na_rep="—")

        st.dataframe(styled_weather, use_container_width=True, hide_index=True)
    else:
        st.dataframe(measured_df, use_container_width=True, hide_index=True)

    st.subheader("9 päeva prognoos")
    forecast_display = [{
        "Kuupäev": r["weather_date"],
        "Min °C": r.get("temp_min_c"),
        "Max °C": r.get("temp_max_c"),
        "Tuul m/s": r.get("wind_avg_ms"),
        "Niiskus %": r.get("humidity_avg_pct"),
        "Sademed mm": r.get("precipitation_mm"),
        "ET0 mm": r.get("et0_mm"),
        "Radiatsioon MJ/m²": r.get("radiation_mj_m2"),
        "Kontroll": r.get("check_message"),
        "Olek": "🔵 Prognoos" if r.get("checked") else "🔴 Vigane prognoos",
    } for r in forecast_rows]
    st.dataframe(pd.DataFrame(forecast_display), use_container_width=True, hide_index=True)

with tabs[3]:
    st.subheader("Prognoos")
    st.markdown("#### Andmete valmisolek")
    st.caption(
        "Kontrollime, kas ajaloolistest korjetest saab moodustada päris õppimisnäited: "
        "sama põllu kahe järjestikuse korje vahel peab olema täielik mõõdetud ilm. "
        "Tänane pooleliolev korjepäev ei blokeeri õppimist."
    )

    readiness_start = date(TODAY.year, 7, 1)
    harvest_rows = db.get_harvest_history(limit=2000)

    # Korjepäevad ja viimane täielik 3/3 päev. Pooleliolevat tänast päeva õppesse ei võeta.
    harvest_by_day = {}
    for row in harvest_rows:
        day_str = str(row.get("harvest_date") or "")
        if day_str:
            harvest_by_day.setdefault(day_str, []).append(row)

    complete_harvest_days = []
    for day_str, day_rows in harvest_by_day.items():
        fields = {int(r.get("field_no")) for r in day_rows if r.get("field_no") is not None}
        if len(day_rows) == 3 and len(fields) == 3:
            try:
                complete_harvest_days.append(date.fromisoformat(day_str))
            except ValueError:
                pass

    last_complete_harvest = max(complete_harvest_days) if complete_harvest_days else None
    latest_harvest = None
    valid_days = []
    for day_str in harvest_by_day:
        try:
            valid_days.append(date.fromisoformat(day_str))
        except ValueError:
            pass
    if valid_days:
        latest_harvest = max(valid_days)

    # Korjeridade baaskvaliteet.
    harvest_problems = []
    estimated_harvest_rows = 0
    seen_keys = set()
    represented_fields = set()
    parsed_rows = []
    for row in harvest_rows:
        day_str = str(row.get("harvest_date") or "")
        field_no = row.get("field_no")
        try:
            field_no_int = int(field_no)
        except (TypeError, ValueError):
            field_no_int = None
        try:
            harvest_day = date.fromisoformat(day_str) if day_str else None
        except ValueError:
            harvest_day = None

        if field_no_int is not None:
            represented_fields.add(field_no_int)

        key = (day_str, field_no_int)
        if key in seen_keys:
            harvest_problems.append(f"Duplikaat: {day_str}, põld {field_no_int}")
        seen_keys.add(key)

        if harvest_day is None:
            harvest_problems.append(f"Vigane või puuduv korjekuupäev: {day_str or '—'}")
        if field_no_int is None or not 1 <= field_no_int <= 14:
            harvest_problems.append(f"Vigane põld: {field_no}")
        quality = str(row.get("data_quality") or "").strip().lower()
        is_estimated = quality in {"hinnanguline", "ligikaudne"}
        if is_estimated:
            estimated_harvest_rows += 1
        else:
            for field_name in ("a", "b", "c", "xl", "total"):
                if row.get(field_name) is None:
                    harvest_problems.append(f"{day_str} põld {field_no}: {field_name.upper()} puudub")

        if harvest_day is not None and field_no_int is not None:
            parsed_rows.append((field_no_int, harvest_day, row))

    missing_fields = [f for f in range(1, 15) if f not in represented_fields]

    # Mõõdetud ööpäevailma saab ausalt nõuda ainult lõpetatud kalendripäevadelt.
    # Tänast päeva ei märgita enam puuduvaks isegi siis, kui tänane 3/3 korje on juba sisestatud.
    weather_target_end = min(last_complete_harvest, TODAY - timedelta(days=1)) if last_complete_harvest else None
    weather_missing = []
    weather_rows = []
    weather_by_day = {}
    required_weather = (
        "temp_min_c", "temp_max_c", "wind_avg_ms", "radiation_mj_m2",
        "humidity_avg_pct", "precipitation_mm", "et0_mm",
    )
    if weather_target_end and weather_target_end >= readiness_start:
        weather_missing = db.get_incomplete_measured_dates(readiness_start, weather_target_end)
        weather_rows = db.get_weather_rows(readiness_start, weather_target_end)
        for wr in weather_rows:
            if wr.get("data_kind") == "measured":
                weather_by_day[str(wr.get("weather_date"))] = wr

    def _weather_day_ok(day_value: date) -> bool:
        wr = weather_by_day.get(day_value.isoformat())
        return bool(
            wr
            and wr.get("checked")
            and all(wr.get(name) is not None for name in required_weather)
        )

    # Päris õppimisnäide = ühe põllu korje, millele eelneb sama põllu varasem korje.
    # Ilmaaken on päev pärast eelmist korjet kuni jooksva korjepäevani (kaasa arvatud).
    rows_by_field = {f: [] for f in range(1, 15)}
    if weather_target_end:
        for field_no, harvest_day, row in parsed_rows:
            if harvest_day <= weather_target_end:
                rows_by_field[field_no].append((harvest_day, row))
    for field_no in rows_by_field:
        rows_by_field[field_no].sort(key=lambda item: item[0])

    usable_samples = []
    incomplete_samples = []
    first_harvest_rows = []
    for field_no, items in rows_by_field.items():
        for idx, (current_day, row) in enumerate(items):
            if idx == 0:
                first_harvest_rows.append((field_no, current_day))
                continue
            previous_day, previous_row = items[idx - 1]
            window_start = previous_day + timedelta(days=1)
            window_end = current_day
            expected_days = max(0, (window_end - window_start).days + 1)
            missing_days = []
            cursor = window_start
            while cursor <= window_end:
                if not _weather_day_ok(cursor):
                    missing_days.append(cursor)
                cursor += timedelta(days=1)

            sample = {
                "field_no": field_no,
                "previous_day": previous_day,
                "current_day": current_day,
                "interval_days": (current_day - previous_day).days,
                "weather_days": expected_days,
                "missing_days": missing_days,
                "current_row": row,
                "previous_row": previous_row,
                "previous2_row": items[idx - 2][1] if idx >= 2 else None,
            }
            if missing_days:
                incomplete_samples.append(sample)
            else:
                usable_samples.append(sample)

    weather_ready = bool(weather_target_end) and not weather_missing
    harvest_ready = bool(last_complete_harvest) and not harvest_problems and not missing_fields
    sample_ready = bool(usable_samples) and not incomplete_samples
    training_ready = weather_ready and harvest_ready and sample_ready

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Õppimisnäiteid", len(usable_samples))
    m2.metric("Ilmaauguga näiteid", len(incomplete_samples))
    m3.metric("Põlde esindatud", f"{len(represented_fields)}/14")
    m4.metric("Ilma kontroll kuni", weather_target_end.strftime("%d.%m") if weather_target_end else "—")

    if training_ready:
        st.success(
            f"✅ Andmestik on õppimiseks tehniliselt valmis kuni {last_complete_harvest.strftime('%d.%m.%Y')}. "
            f"Täieliku ilmavahemikuga õppimisnäiteid on {len(usable_samples)}."
        )
    else:
        st.warning("Õppimisandmestik ei ole veel täielikult valmis. Allpool on näha, mis piirab õppimisnäiteid.")

    c1, c2 = st.columns(2)
    with c1:
        st.markdown("##### Ilm")
        if weather_target_end is None or weather_target_end < readiness_start:
            st.info("Mõõdetud ilma kontroll algab pärast esimest lõpetatud korjepäeva.")
        elif weather_ready:
            days_count = (weather_target_end - readiness_start).days + 1
            st.success(
                f"🟢 Mõõdetud ilm 01.07–{weather_target_end.strftime('%d.%m')} on täielik: "
                f"{days_count}/{days_count} päeva."
            )
        else:
            expected = (weather_target_end - readiness_start).days + 1
            ok_count = max(0, expected - len(weather_missing))
            old_missing = [d for d in weather_missing if d < TODAY - timedelta(days=2)]
            status_text = (
                f"Mõõdetud ilm 01.07–{weather_target_end.strftime('%d.%m')}: "
                f"{ok_count}/{expected} päeva valmis."
            )
            if old_missing:
                st.error("🔴 " + status_text)
            else:
                st.warning("🟡 " + status_text + " Viimased ametlikud päevakomponendid võivad saabuda viitega.")

            friendly = {
                "temp_min_c": "Tmin", "temp_max_c": "Tmax", "wind_avg_ms": "tuul",
                "radiation_mj_m2": "radiatsioon", "humidity_avg_pct": "niiskus",
                "precipitation_mm": "sademed", "et0_mm": "ET0",
            }
            details = []
            for d in weather_missing:
                wr = weather_by_day.get(d.isoformat())
                if not wr:
                    details.append(f"{d.strftime('%d.%m')}: mõõdetud päeva rida puudub")
                    continue
                missing_parts = [friendly[k] for k in required_weather if wr.get(k) is None]
                details.append(f"{d.strftime('%d.%m')}: " + ", ".join(missing_parts))
            if details:
                st.caption("Puudu: " + " | ".join(details[:10]))
            st.caption("„Uuenda ilm kohe” kontrollib puudulikud päevad uuesti; tänast päeva siia enam ei arvestata.")

    with c2:
        st.markdown("##### Korjed")
        if harvest_ready:
            st.success("🟢 Korjeread korras ja kõik 14 põldu on ajaloos esindatud.")
        else:
            if missing_fields:
                st.warning("Ajaloost puuduvad põllud: " + ", ".join(map(str, missing_fields)))
            if harvest_problems:
                st.warning(f"Korjeandmetes on {len(harvest_problems)} tehnilist kontrollkohta.")
                with st.expander("Näita korjeandmete kontrollkohti"):
                    for problem in harvest_problems[:100]:
                        st.write("• " + problem)
        if estimated_harvest_rows:
            st.caption(
                f"{estimated_harvest_rows} hinnangulist/ligikaudset ajaloorida kasutatakse ajajooneks, "
                "kuid mitte mudeli sihtreana."
            )

    st.markdown("##### Õppimisnäited põldude kaupa")
    st.caption(
        "Esimene teadaolev korje igal põllul on lähtepunkt, mitte õppimisnäide. "
        "Järgmise korje näide kasutab selle põllu kahe korje vahele jäävat ilma."
    )

    field_summary = []
    for field_no in range(1, 15):
        usable_n = sum(1 for s in usable_samples if s["field_no"] == field_no)
        bad_n = sum(1 for s in incomplete_samples if s["field_no"] == field_no)
        harvest_n = len(rows_by_field.get(field_no, []))
        field_summary.append({
            "Põld": field_no,
            "Korjeid": harvest_n,
            "Õppimisnäiteid": usable_n,
            "Ilmaauguga": bad_n,
        })
    st.dataframe(pd.DataFrame(field_summary), use_container_width=True, hide_index=True)

    if incomplete_samples:
        with st.expander("Näita ilmaauguga õppimisnäiteid"):
            for sample in incomplete_samples[:100]:
                missing_text = ", ".join(d.strftime("%d.%m") for d in sample["missing_days"])
                st.write(
                    f"• Põld {sample['field_no']}: {sample['previous_day'].strftime('%d.%m')} → "
                    f"{sample['current_day'].strftime('%d.%m')} — puuduv ilm: {missing_text}"
                )

    st.markdown("##### Õppimisandmestik")
    st.caption(
        "Üks rida = ühe põllu üks järgmine korje. Ilmatunnused arvutatakse ainult selle põllu "
        "eelmise ja järgmise korje vahele jäävatest mõõdetud päevadest. A+B+C põhimudeli siht on tegelik A+B+C; XL hinnatakse eraldi."
    )

    # Bioloogilise koormuse jäljed arvutatakse ainult varasematest päriselt mõõdetud
    # sama põllu korjetest. Toorest eelmist saaki ei kasutata ankru ega prognoosi alusena.
    # Koormusindeks küsib: kas konkreetne korje oli selle põllu enda varasema tasemega
    # võrreldes ebatavaliselt suur, ning kas sellel on 1–2 korje järel stabiilne mõju.
    load_state_by_field_date = {}
    for _field_no, _rows in rows_by_field.items():
        _abc_hist = []
        _peak_hist = []
        # rows_by_field sisaldab (harvest_day, row) paare ja on juba kuupäeva järgi sorteeritud.
        # Ära käsitle paari dict-ina: biokoormuse arvutus kasutab päris harvest-rida.
        for _d, _row in _rows:
            try:
                _a = float(_row.get("a")); _b = float(_row.get("b")); _c = float(_row.get("c"))
            except (TypeError, ValueError, AttributeError):
                continue
            _quality = str(_row.get("data_quality") or "").strip().lower()
            if _quality in {"hinnanguline", "ligikaudne"}:
                continue
            _abc = _a + _b + _c
            _prior = _abc_hist[-3:]
            _baseline = float(np.mean(_prior)) if _prior else None
            _load_index = (_abc / _baseline) if (_baseline is not None and _baseline > 0) else None
            _overload = max(0.0, _load_index - 1.0) if _load_index is not None else None
            _two_load = None
            if _prior:
                _two_mean = float(np.mean([_abc, _prior[-1]]))
                _two_load = (_two_mean / _baseline) if _baseline > 0 else None
            _peak = 1.0 if (_load_index is not None and _load_index >= 1.25) else 0.0 if _load_index is not None else None
            load_state_by_field_date[(int(_field_no), _d)] = {
                "Koormusindeks -1": _load_index,
                "Ülekoormus -1": _overload,
                "2 korje koormus": _two_load,
                "Tipukorje -1": _peak,
                "Tipukorje -2": _peak_hist[-1] if _peak_hist else None,
            }
            _abc_hist.append(_abc)
            _peak_hist.append(_peak)

    training_rows = []
    for sample in usable_samples:
        current_row = sample.get("current_row") or {}
        previous_row = sample.get("previous_row") or {}
        previous2_row = sample.get("previous2_row") or {}

        # Õpperea siht peab olema päriselt numbriline. Osaline vana kirje võib olla
        # kasvuperioodi alguspunkt, kuid seda ei kasutata ise sihtreana.
        try:
            target_total = float(current_row.get("total"))
        except (TypeError, ValueError):
            continue

        # Hinnangulist vana korjet ei kasuta mudeli sihtreana. See võib jääda
        # ajajoone lähtepunktiks, kuid oletuslik saak ei tohi õpetada mudelit nagu tegelik mõõtmine.
        current_quality = str(current_row.get("data_quality") or "").strip().lower()
        if current_quality == "hinnanguline":
            continue

        window_weather = []
        cursor = sample["previous_day"] + timedelta(days=1)
        while cursor <= sample["current_day"]:
            wr = weather_by_day.get(cursor.isoformat())
            if wr:
                window_weather.append(wr)
            cursor += timedelta(days=1)

        if len(window_weather) != sample["weather_days"] or not window_weather:
            continue

        tmin = [_n(w.get("temp_min_c")) for w in window_weather]
        tmax = [_n(w.get("temp_max_c")) for w in window_weather]
        daily_mean_t = [(lo + hi) / 2 for lo, hi in zip(tmin, tmax)]
        rad = [_n(w.get("radiation_mj_m2")) for w in window_weather]
        rain = [_n(w.get("precipitation_mm")) for w in window_weather]
        hum = [_n(w.get("humidity_avg_pct")) for w in window_weather]
        et0 = [_n(w.get("et0_mm")) for w in window_weather]
        wind = [_n(w.get("wind_avg_ms")) for w in window_weather]

        previous_total = previous_row.get("total")
        try:
            previous_total = float(previous_total) if previous_total is not None else None
        except (TypeError, ValueError):
            previous_total = None

        def _maybe_float(value):
            try:
                return float(value) if value is not None else None
            except (TypeError, ValueError):
                return None

        current_a = _maybe_float(current_row.get("a"))
        current_b = _maybe_float(current_row.get("b"))
        current_c = _maybe_float(current_row.get("c"))
        current_xl = _maybe_float(current_row.get("xl"))
        if current_a is None or current_b is None or current_c is None or current_xl is None:
            continue
        target_abc = current_a + current_b + current_c
        target_cb = (current_c / current_b) if current_b > 0 else None

        previous_xl = _maybe_float(previous_row.get("xl"))
        previous2_xl = _maybe_float(previous2_row.get("xl"))
        previous2_total = _maybe_float(previous2_row.get("total"))
        previous_a = _maybe_float(previous_row.get("a"))
        previous_b = _maybe_float(previous_row.get("b"))
        previous_c = _maybe_float(previous_row.get("c"))
        previous2_a = _maybe_float(previous2_row.get("a"))
        previous2_b = _maybe_float(previous2_row.get("b"))
        previous2_c = _maybe_float(previous2_row.get("c"))
        previous_abc = (previous_a + previous_b + previous_c) if None not in (previous_a, previous_b, previous_c) else None
        previous2_abc = (previous2_a + previous2_b + previous2_c) if None not in (previous2_a, previous2_b, previous2_c) else None

        # Kui eelmine saak oli ainult hinnanguline, kasutame selle kuupäeva intervalli
        # määramiseks, kuid mitte saagi/XL lag-tunnusena. Mudeli missing-indikaator
        # saab siis ausalt aru, et eelmine saagitase pole usaldusväärne.
        prev_quality = str(previous_row.get("data_quality") or "").strip().lower()
        prev2_quality = str(previous2_row.get("data_quality") or "").strip().lower()
        if prev_quality == "hinnanguline":
            previous_total = previous_abc = previous_xl = None
        if prev2_quality == "hinnanguline":
            previous2_total = previous2_abc = previous2_xl = None

        previous_xl_share = (previous_xl / previous_total) if (previous_xl is not None and previous_total and previous_total > 0) else None
        previous2_xl_share = (previous2_xl / previous2_total) if (previous2_xl is not None and previous2_total and previous2_total > 0) else None
        previous_cb = None if prev_quality == "hinnanguline" else ((previous_c / previous_b) if (previous_c is not None and previous_b and previous_b > 0) else None)
        previous2_cb = None if prev2_quality == "hinnanguline" else ((previous2_c / previous2_b) if (previous2_c is not None and previous2_b and previous2_b > 0) else None)
        yield_trend = (previous_abc - previous2_abc) if (previous_abc is not None and previous2_abc is not None) else None
        prev_load = load_state_by_field_date.get((int(sample["field_no"]), sample["previous_day"]), {})

        def _tail_weather(n):
            tail = window_weather[-min(n, len(window_weather)):]
            tmins = [_n(w.get("temp_min_c")) for w in tail]
            tmaxs = [_n(w.get("temp_max_c")) for w in tail]
            mt = [(lo + hi) / 2 for lo, hi in zip(tmins, tmaxs)]
            rad_sum = sum(_n(w.get("radiation_mj_m2")) for w in tail)
            rain_sum = sum(_n(w.get("precipitation_mm")) for w in tail)
            et0_sum = sum(_n(w.get("et0_mm")) for w in tail)
            rh_mean = sum(_n(w.get("humidity_avg_pct")) for w in tail) / len(tail)
            wind_mean = sum(_n(w.get("wind_avg_ms")) for w in tail) / len(tail)
            tmax_mean = sum(tmaxs) / len(tmaxs)

            return {
                f"T viim{n}": sum(mt) / len(mt),
                f"Tmin viim{n}": sum(tmins) / len(tmins),
                f"Tmax viim{n}": tmax_mean,
                f"Rad viim{n}": rad_sum,
                f"Sade viim{n}": rain_sum,
                f"ET0 viim{n}": et0_sum,
                f"Niiskus viim{n}": rh_mean,
                f"Tuul viim{n}": wind_mean,
                f"Tuul×Tmax viim{n}": wind_mean * tmax_mean,
                f"Tuul×Rad/p viim{n}": wind_mean * (rad_sum / len(tail)),
                f"Tuul×ET0/p viim{n}": wind_mean * (et0_sum / len(tail)),
                f"Tuul×Kuivus viim{n}": wind_mean * (100.0 - rh_mean),
                f"Päevapikkus viim{n}": float(np.mean([
                    _daylength_hours(sample["current_day"] - timedelta(days=i))
                    for i in range(min(n, sample["interval_days"]))
                ])) if sample["interval_days"] > 0 else _daylength_hours(sample["current_day"]),
            }

        tail1 = _tail_weather(1)
        tail2 = _tail_weather(2)
        tail3 = _tail_weather(3)

        temp_curve = _temperature_curve_features(tmin, tmax)

        training_rows.append({
            "Kuupäev": sample["current_day"],
            "Põld": sample["field_no"],
            "Intervall p": sample["interval_days"],
            "Saak": target_total,
            "ABC saak": target_abc,
            "C/B siht": target_cb,
            "Eelmine ABC": previous_abc,
            "Eelmine saak": previous_total,
            "XL -1": previous_xl,
            "XL -2": previous2_xl,
            "T kesk": sum(daily_mean_t) / len(daily_mean_t),
            "Tmin kesk": sum(tmin) / len(tmin),
            "Tmax kesk": sum(tmax) / len(tmax),
            "Tmin min": min(tmin),
            "Tmax max": max(tmax),
            **temp_curve,
            "Soojad ööd 16+": sum(1 for v in tmin if v >= 16.0),
            "Soojad ööd 18+": sum(1 for v in tmin if v >= 18.0),
            "Jahedad ööd 12-": sum(1 for v in tmin if v <= 12.0),
            "Soojad ööd 16+ %": 100.0 * sum(1 for v in tmin if v >= 16.0) / len(tmin),
            "Soojad ööd 18+ %": 100.0 * sum(1 for v in tmin if v >= 18.0) / len(tmin),
            "Jahedad ööd 12- %": 100.0 * sum(1 for v in tmin if v <= 12.0) / len(tmin),
            "Radiatsioon Σ": sum(rad),
            "Radiatsioon/p": sum(rad) / len(rad),
            "Sademed Σ": sum(rain),
            "Niiskus kesk": sum(hum) / len(hum),
            "ET0 Σ": sum(et0),
            "Tuul kesk": sum(wind) / len(wind),

            # Tuule koostoimed. Need EI lähe automaatselt baasmudelisse,
            # vaid Jäljeotsija testib neid walk-forward meetodil.
            "Tuul×Tmax": (sum(wind) / len(wind)) * (sum(tmax) / len(tmax)),
            "Tuul×Rad/p": (sum(wind) / len(wind)) * (sum(rad) / len(rad)),
            "Tuul×ET0/p": (sum(wind) / len(wind)) * (sum(et0) / len(et0)),
            "Tuul×Kuivus": (sum(wind) / len(wind)) * (100.0 - (sum(hum) / len(hum))),

            # Fotoperiood / päevapikkus.
            "Päevapikkus": _daylength_hours(sample["current_day"]),
            "Päevapikkus Δ7p": _daylength_change_7d(sample["current_day"]),
            "Päevapikkus kasvukesk": float(np.mean([
                _daylength_hours(sample["previous_day"] + timedelta(days=i))
                for i in range(1, sample["interval_days"] + 1)
            ])) if sample["interval_days"] > 0 else _daylength_hours(sample["current_day"]),

            "A": current_row.get("a"),
            "B": current_row.get("b"),
            "C": current_row.get("c"),
            "XL": current_row.get("xl"),
            # Jäljeotsija kandidaadid. Neid ei näidata põhitabelis ega kasutata baasmudelis.
            "Eelmine2 ABC": previous2_abc,
            "ABC trend": yield_trend,
            "Eelmine2 saak": previous2_total,
            "XL osakaal -1": previous_xl_share,
            "XL osakaal -2": previous2_xl_share,
            "C/B -1": previous_cb,
            "C/B -2": previous2_cb,
            "Koormusindeks -1": prev_load.get("Koormusindeks -1"),
            "Ülekoormus -1": prev_load.get("Ülekoormus -1"),
            "2 korje koormus": prev_load.get("2 korje koormus"),
            "Tipukorje -1": prev_load.get("Tipukorje -1"),
            "Tipukorje -2": prev_load.get("Tipukorje -2"),
            **tail1, **tail2, **tail3,
            "Andmekvaliteet": current_row.get("data_quality") or "",
        })

    if training_rows:
        training_df = pd.DataFrame(training_rows).sort_values(["Kuupäev", "Põld"], ascending=[False, True])
        t1, t2, t3 = st.columns(3)
        t1.metric("Valmis õppimisridu", len(training_df))
        t2.metric("Keskmine intervall", f"{training_df['Intervall p'].mean():.1f} p")
        t3.metric("Keskmine A+B+C", f"{training_df['ABC saak'].mean():.1f} kasti")

        visible_training_cols = [
            "Kuupäev", "Põld", "Intervall p", "ABC saak", "C/B siht", "XL", "Saak", "Eelmine ABC",
            "T kesk", "Tmin kesk", "Tmax kesk", "Tmin min", "Tmax max", "Radiatsioon Σ", "Radiatsioon/p", "Sademed Σ",
            "Niiskus kesk", "ET0 Σ", "Tuul kesk", "A", "B", "C", "Andmekvaliteet",
        ]
        display_df = training_df[visible_training_cols].copy()
        display_df["Kuupäev"] = display_df["Kuupäev"].map(lambda d: d.strftime("%d.%m"))
        st.dataframe(
            display_df.style.format({
                "ABC saak": "{:.1f}",
                "C/B siht": lambda v: "—" if pd.isna(v) else f"{float(v):.2f}",
                "Saak": "{:.1f}",
                "Eelmine ABC": lambda v: "—" if pd.isna(v) else f"{v:.1f}",
                "T kesk": "{:.1f}",
                "Tmin kesk": "{:.1f}",
                "Tmax kesk": "{:.1f}",
                "Tmin min": "{:.1f}",
                "Tmax max": "{:.1f}",
                "Radiatsioon Σ": "{:.1f}",
                "Radiatsioon/p": "{:.1f}",
                "Sademed Σ": "{:.1f}",
                "Niiskus kesk": "{:.1f}",
                "ET0 Σ": "{:.1f}",
                "Tuul kesk": "{:.1f}",
                "A": lambda v: "—" if pd.isna(v) else f"{float(v):.1f}",
                "B": lambda v: "—" if pd.isna(v) else f"{float(v):.1f}",
                "C": lambda v: "—" if pd.isna(v) else f"{float(v):.1f}",
                "XL": lambda v: "—" if pd.isna(v) else f"{float(v):.1f}",
            }),
            use_container_width=True,
            hide_index=True,
        )

        st.caption(
            "Radiatsioon Σ, sademed Σ ja ET0 Σ on kogu korjevahemiku summad; T, niiskus ja tuul on "
            "sama vahemiku päevade keskmised. Põhimudeli siht on A+B+C; XL käsitletakse eraldi mürasema korjejäägi komponendina."
        )

        csv_df = training_df.copy()
        csv_df["Kuupäev"] = csv_df["Kuupäev"].map(lambda d: d.isoformat())
        st.download_button(
            "Laadi õppimisandmestik CSV-na",
            data=csv_df.to_csv(index=False).encode("utf-8-sig"),
            file_name="kurgimootor_training_dataset.csv",
            mime="text/csv",
        )

        st.markdown("##### A+B+C kasvupotentsiaali mudel + eraldi XL-komponent")
        st.caption(
            "Temperatuurivastus on mittelineaarne: külma- ja kuumastressil on eraldi tsoonid ning ruutliikmed. "
            "Seetõttu ei käsitle mootor näiteks 12→14 °C ja 16→18 °C öist muutust võrdse mõjuna. "
            "Murdepunktid on bioloogiliselt informeeritud; mõju tugevuse õpib mudel meie enda korjetest."
        )
        st.caption(
            "Põhimudel ennustab ainult A+B+C saaki positiivsel kasvupotentsiaali skaalal. "
            "Baasmudel kasutab Tmin/Tmax mittelineaarset kasvukõverat, muud ilma, korjeintervalli, hooaja faasi ja põllu identiteeti; eelmine saak ei ole prognoosi ankur. "
            "XL prognoositakse eraldi mürasema korjejäägi komponendina. Mõlemat hinnatakse ajaliselt ausa walk-forward testiga."
        )

        # Baasmudel on teadlikult puhas bioloogiline mudel: ilm + kasvuaeg + põld + hooaja faas.
        # Eelmise korje saak EI ole baasmudeli kohustuslik sisend; Jäljeotsija võib selle
        # eraldi kandidaadina sisse lubada ainult siis, kui aus walk-forward test tõestab kasu.
        base_cont_cols = [
            "Intervall p", "Hooajapäev",

            # V6.4 nonlinear-temperature:
            # temperatuur EI sisene enam ühe lineaarse Tmin/Tmax koefitsiendina.
            # Külmastressi ruutliige võimaldab nt 12 C ööl olla ebaproportsionaalselt
            # halvem kui 14 C, samal ajal kui 16 -> 18 ei pea andma sama suurt võitu.
            "Öö jahedus <16", "Öö jahedus² <16",
            "Öö soojus 16-20", "Öö kuumus >20",
            "Päeva jahedus <20", "Päeva jahedus² <20",
            "Päeva soojus 20-28",
            "Päeva kuumus >30", "Päeva kuumus² >30",

            "Radiatsioon Σ", "Radiatsioon/p",
            "Sademed Σ", "Niiskus kesk", "ET0 Σ", "Tuul kesk",
        ]
        model_df = training_df.copy().sort_values(["Kuupäev", "Põld"]).reset_index(drop=True)
        model_df["Hooajapäev"] = pd.to_datetime(model_df["Kuupäev"]).map(
            lambda d: (d.date() - date(2026, 7, 1)).days
        )
        fields = model_df["Põld"].astype(int).to_numpy()
        dates = pd.to_datetime(model_df["Kuupäev"]).dt.date.to_numpy()
        X_base = model_df[base_cont_cols].astype(float).to_numpy()

        y_abc = pd.to_numeric(model_df["ABC saak"], errors="coerce").to_numpy(dtype=float)
        # V6.4: A+B+C operatiivne mudel õpib multiplikatiivsel positiivsel kasvupotentsiaali skaalal.
        # EPS on ainult log(0) numbriline kaitse, mitte bioloogiline saagipõrand.
        ABC_LOG_EPS = 0.05
        log_y_abc = np.where(
            np.isfinite(y_abc) & (y_abc >= 0),
            np.log(np.maximum(y_abc, ABC_LOG_EPS)),
            np.nan,
        )
        y_xl = pd.to_numeric(model_df["XL"], errors="coerce").to_numpy(dtype=float)
        y_total = pd.to_numeric(model_df["Saak"], errors="coerce").to_numpy(dtype=float)
        y_cb = pd.to_numeric(model_df["C/B siht"], errors="coerce").to_numpy(dtype=float)
        log_y_cb = np.where(np.isfinite(y_cb) & (y_cb > 0), np.log(y_cb), np.nan)
        raw_prev_abc = pd.to_numeric(model_df["Eelmine ABC"], errors="coerce").to_numpy(dtype=float)
        raw_prev_total = pd.to_numeric(model_df["Eelmine saak"], errors="coerce").to_numpy(dtype=float)
        raw_xl1 = pd.to_numeric(model_df["XL -1"], errors="coerce").to_numpy(dtype=float)
        raw_xl2 = pd.to_numeric(model_df["XL -2"], errors="coerce").to_numpy(dtype=float)
        raw_cb1 = pd.to_numeric(model_df["C/B -1"], errors="coerce").to_numpy(dtype=float)
        raw_cb2 = pd.to_numeric(model_df["C/B -2"], errors="coerce").to_numpy(dtype=float)

        def _build_ridge_design(train_idx, test_idx, extra_arrays):
            tr_parts = [X_base[train_idx]]
            te_parts = [X_base[test_idx]]
            tr_missing_parts, te_missing_parts = [], []
            fills = []
            for arr in extra_arrays:
                tr = arr[train_idx]
                te = arr[test_idx]
                finite = tr[np.isfinite(tr)]
                fill = float(np.median(finite)) if len(finite) else 0.0
                fills.append(fill)
                tr_parts.append(np.where(np.isfinite(tr), tr, fill).reshape(-1, 1))
                te_parts.append(np.where(np.isfinite(te), te, fill).reshape(-1, 1))
                tr_missing_parts.append((~np.isfinite(tr)).astype(float).reshape(-1, 1))
                te_missing_parts.append((~np.isfinite(te)).astype(float).reshape(-1, 1))
            xtr = np.column_stack(tr_parts)
            xte = np.column_stack(te_parts)
            means = xtr.mean(axis=0)
            scales = xtr.std(axis=0)
            scales[scales < 1e-9] = 1.0
            ztr = (xtr - means) / scales
            zte = (xte - means) / scales
            ftr = np.zeros((len(train_idx), 14), dtype=float)
            fte = np.zeros((len(test_idx), 14), dtype=float)
            for ri, f in enumerate(fields[train_idx]):
                if 1 <= int(f) <= 14:
                    ftr[ri, int(f) - 1] = 1.0
            for ri, f in enumerate(fields[test_idx]):
                if 1 <= int(f) <= 14:
                    fte[ri, int(f) - 1] = 1.0
            tr_missing = np.column_stack(tr_missing_parts) if tr_missing_parts else np.empty((len(train_idx), 0))
            te_missing = np.column_stack(te_missing_parts) if te_missing_parts else np.empty((len(test_idx), 0))
            Xtr = np.column_stack([np.ones(len(train_idx)), ztr, tr_missing, ftr])
            Xte = np.column_stack([np.ones(len(test_idx)), zte, te_missing, fte])
            return Xtr, Xte, means, scales, fills

        def _ridge_walk_predict(target, extra_arrays, train_idx, test_idx, alpha=10.0, floor_zero=True, field_alpha=80.0):
            Xtr, Xte, _, _, _ = _build_ridge_design(train_idx, test_idx, extra_arrays)
            penalty = np.eye(Xtr.shape[1]) * alpha
            penalty[0, 0] = 0.0
            # 14 viimast veergu on põllu one-hot tunnused. Õppimisandmestik on veel väike,
            # seetõttu kasutame siin tugevat partial-pooling kahandamist: põllu eripära jääb
            # alles, kuid ei tohi üksinda weather-first prognoosi nulli/äärmusse suruda.
            penalty[-14:, -14:] = np.eye(14) * field_alpha
            beta = np.linalg.pinv(Xtr.T @ Xtr + penalty) @ Xtr.T @ target[train_idx]
            values = Xte @ beta
            return np.maximum(values, 0.0) if floor_zero else values

        def _abc_growth_walk_predict(extra_arrays, train_idx, test_idx, alpha=10.0, field_alpha=80.0, z_clip=2.5):
            """V6.4 A+B+C: multiplicative/positive growth-potential model.

            Õpib log(A+B+C) multiplikatiivsel skaalal. Ilma ja muude pidevate tunnuste z-skoorid
            piiratakse treeningu mõistlikku vahemikku, et 6–9 päeva prognoosi
            ekstreemne ilm ei saaks lineaarset latentset mudelit absurdselt ekstrapoleerida.
            """
            valid_train = train_idx[np.isfinite(log_y_abc[train_idx])]
            if len(valid_train) < min_train_rows:
                return np.full(len(test_idx), np.nan, dtype=float)
            Xtr, Xte, _, _, _ = _build_ridge_design(valid_train, test_idx, extra_arrays)
            n_numeric = X_base.shape[1] + len(extra_arrays)
            # intercept on veerg 0; sellele järgnevad standardiseeritud arvulised tunnused
            Xtr[:, 1:1+n_numeric] = np.clip(Xtr[:, 1:1+n_numeric], -z_clip, z_clip)
            Xte[:, 1:1+n_numeric] = np.clip(Xte[:, 1:1+n_numeric], -z_clip, z_clip)
            penalty = np.eye(Xtr.shape[1]) * alpha
            penalty[0, 0] = 0.0
            penalty[-14:, -14:] = np.eye(14) * field_alpha
            beta = np.linalg.pinv(Xtr.T @ Xtr + penalty) @ Xtr.T @ log_y_abc[valid_train]
            latent = Xte @ beta
            # exp() teeb mudeli multiplikatiivseks ja positiivseks. Väga halb ilm võib
            # viia prognoosi väga madalale, kuid mitte lineaarse algebra tõttu negatiivseks.
            return np.exp(np.clip(latent, np.log(ABC_LOG_EPS), 6.0))

        min_train_rows = 10
        abc_predictions = np.full(len(model_df), np.nan, dtype=float)
        xl_predictions = np.full(len(model_df), np.nan, dtype=float)
        for test_day in sorted(set(dates)):
            test_idx = np.where(dates == test_day)[0]
            train_idx = np.where(dates < test_day)[0]
            if len(train_idx) < min_train_rows:
                continue
            # A+B+C BAASMudel: ainult ilm + intervall + hooajapäev + põllu identiteet.
            # Eelmist saaki siin tahtlikult EI kasutata.
            abc_predictions[test_idx] = _abc_growth_walk_predict([], train_idx, test_idx)
            # XL-mudel saab kasutada varasemaid XL-e ning eelmise korje ABC/kogusaaki.
            xl_predictions[test_idx] = _ridge_walk_predict(
                y_xl, [raw_xl1, raw_xl2, raw_prev_abc, raw_prev_total], train_idx, test_idx
            )

        # C/B on eraldi kvaliteedimudel. Õpime log(C/B), et prognoos jääks alati positiivseks.
        cb_predictions = np.full(len(model_df), np.nan, dtype=float)
        for test_day in sorted(set(dates)):
            test_idx = np.where(dates == test_day)[0]
            train_idx = np.where((dates < test_day) & np.isfinite(log_y_cb))[0]
            if len(train_idx) < min_train_rows:
                continue
            log_pred = _ridge_walk_predict(log_y_cb, [raw_cb1], train_idx, test_idx, floor_zero=False)
            cb_predictions[test_idx] = np.exp(np.clip(log_pred, np.log(0.10), np.log(10.0)))

        valid_abc = np.isfinite(abc_predictions)
        valid_xl = np.isfinite(xl_predictions)
        valid_both = valid_abc & valid_xl
        predictions = abc_predictions  # Jäljeotsija baasiks jääb objektiivne A+B+C mudel.
        y = y_abc
        valid_pred = valid_abc
        current_test_mae = None
        current_total_test_mae = None

        if valid_abc.any():
            abc_err = abc_predictions - y_abc
            abc_mae = float(np.mean(np.abs(abc_err[valid_abc])))
            current_test_mae = abc_mae
            abc_rmse = float(np.sqrt(np.mean(abc_err[valid_abc] ** 2)))
            abc_bias = float(np.mean(abc_err[valid_abc]))
            abc_within2 = float(np.mean(np.abs(abc_err[valid_abc]) <= 2.0) * 100.0)

            xl_mae = float(np.mean(np.abs(xl_predictions[valid_xl] - y_xl[valid_xl]))) if valid_xl.any() else None
            total_predictions = abc_predictions + xl_predictions
            if valid_both.any():
                total_err = total_predictions - y_total
                total_mae = float(np.mean(np.abs(total_err[valid_both])))
                current_total_test_mae = total_mae
            else:
                total_mae = None

            r1, r2, r3, r4 = st.columns(4)
            r1.metric("A+B+C MAE", f"{abc_mae:.1f} kasti")
            r2.metric("XL MAE", "—" if xl_mae is None else f"{xl_mae:.1f} kasti")
            r3.metric("Kogu MAE", "—" if total_mae is None else f"{total_mae:.1f} kasti")
            r4.metric("A+B+C ±2 sees", f"{abc_within2:.0f}%")
            tested_days_abc = len(set(dates[np.where(valid_abc)[0]]))
            st.caption(
                f"A+B+C testitud: {int(valid_abc.sum())}/{len(model_df)} rida · {tested_days_abc} testipäeva · "
                f"RMSE {abc_rmse:.1f} · nihe {abc_bias:+.1f}. Kogu = A+B+C prognoos + eraldi XL prognoos."
            )

            baseline_mask = valid_abc & np.isfinite(raw_prev_abc)
            if baseline_mask.any():
                baseline_mae = float(np.mean(np.abs(raw_prev_abc[baseline_mask] - y_abc[baseline_mask])))
                model_same = float(np.mean(np.abs(abc_predictions[baseline_mask] - y_abc[baseline_mask])))
                delta = baseline_mae - model_same
                if delta > 0:
                    st.success(f"A+B+C mudel: MAE {model_same:.1f} vs lihtne 'eelmine A+B+C' {baseline_mae:.1f}. Eelis {delta:.1f} kasti.")
                else:
                    st.warning(f"A+B+C mudel: MAE {model_same:.1f} vs lihtne 'eelmine A+B+C' {baseline_mae:.1f}. Baas on praegu parem.")

            eval_df = model_df[["Kuupäev", "Põld", "ABC saak", "XL", "Saak", "Eelmine ABC"]].copy()
            eval_df["ABC prognoos"] = abc_predictions
            eval_df["XL prognoos"] = xl_predictions
            eval_df["Kogu prognoos"] = abc_predictions + xl_predictions
            eval_df["ABC viga"] = eval_df["ABC prognoos"] - eval_df["ABC saak"]
            eval_df["Kogu viga"] = eval_df["Kogu prognoos"] - eval_df["Saak"]
            eval_df = eval_df.sort_values(["Kuupäev", "Põld"], ascending=[False, True])
            eval_df["Kuupäev"] = eval_df["Kuupäev"].map(lambda d: d.strftime("%d.%m"))
            st.dataframe(
                eval_df.style.format({
                    "ABC saak": "{:.1f}", "XL": "{:.1f}", "Saak": "{:.1f}",
                    "Eelmine ABC": lambda v: "—" if pd.isna(v) else f"{v:.1f}",
                    "ABC prognoos": lambda v: "—" if pd.isna(v) else f"{v:.1f}",
                    "XL prognoos": lambda v: "—" if pd.isna(v) else f"{v:.1f}",
                    "Kogu prognoos": lambda v: "—" if pd.isna(v) else f"{v:.1f}",
                    "ABC viga": lambda v: "—" if pd.isna(v) else f"{v:+.1f}",
                    "Kogu viga": lambda v: "—" if pd.isna(v) else f"{v:+.1f}",
                }), use_container_width=True, hide_index=True,
            )
            st.caption(
                "ABC viga näitab taime tootmise prognoosi viga. Kogu viga sisaldab lisaks XL-komponendi müra. "
                "XL-mudel on eraldi just selleks, et korjejääk ei moonutaks põhimudelit."
            )
        else:
            st.info(f"Ajaliselt ausaks testiks on vaja vähemalt {min_train_rows} varasemat õppimisrida.")

        # -------------------------------------------------------------------------
        # Jäljeotsija v2 — automaatne champion-valik A+B+C põhimudelile
        # -------------------------------------------------------------------------
        # WEATHER-FIRST + BIOLOOGILISE KOORMUSE LUKK:
        # A+B+C baas jääb ilm + intervall + hooaja faas + põld. Operatiivseks korrigeerijaks
        # võivad saada kas ilmast tuletatud jäljed või normaliseeritud bioloogilise koormuse
        # jäljed, kui need läbivad sama range walk-forward stabiilsustesti. Toores eelmine
        # saak/trend/XL/C-B ei saa prognoosi ankurdada ja jäävad diagnostikasse.
        weather_candidate_groups = {
            "Viimase 1 päeva ilm": ["Tmin viim1", "Tmax viim1", "Rad viim1", "Sade viim1", "ET0 viim1", "Niiskus viim1"],
            "Viimase 2 päeva ilm": ["Tmin viim2", "Tmax viim2", "Rad viim2", "Sade viim2", "ET0 viim2", "Niiskus viim2"],
            "Viimase 3 päeva ilm": ["Tmin viim3", "Tmax viim3", "Rad viim3", "Sade viim3", "ET0 viim3", "Niiskus viim3"],

            # Ööd / temperatuur
            "Soojad ööd 16+": ["Soojad ööd 16+ %"],
            "Väga soojad ööd 18+": ["Soojad ööd 18+ %"],
            "Jahedad ööd 12-": ["Jahedad ööd 12- %"],
            "Öötemperatuuri kuju": ["Tmin min", "Soojad ööd 16+ %", "Jahedad ööd 12- %"],
            "Päev/öö äärmused": ["Tmin min", "Tmax max"],

            # Kontrollkatse: kas toore lineaarse Tmin/Tmax lisamine annab pärast
            # mittelineaarset baasi veel päriselt midagi juurde?
            "Lineaarne Tmin/Tmax lisaks": ["Tmin kesk", "Tmax kesk"],

            # Tuule koostoimed
            "Tuul × Tmax": ["Tuul×Tmax"],
            "Tuul × radiatsioon": ["Tuul×Rad/p"],
            "Tuul × ET0": ["Tuul×ET0/p"],
            "Tuul × kuivus": ["Tuul×Kuivus"],
            "Tuulestress kombineeritud": ["Tuul×Tmax", "Tuul×Rad/p", "Tuul×ET0/p", "Tuul×Kuivus"],

            # Viimase 1–3 päeva tuulestress
            "Tuulestress viim1": ["Tuul×Tmax viim1", "Tuul×Rad/p viim1", "Tuul×ET0/p viim1", "Tuul×Kuivus viim1"],
            "Tuulestress viim2": ["Tuul×Tmax viim2", "Tuul×Rad/p viim2", "Tuul×ET0/p viim2", "Tuul×Kuivus viim2"],
            "Tuulestress viim3": ["Tuul×Tmax viim3", "Tuul×Rad/p viim3", "Tuul×ET0/p viim3", "Tuul×Kuivus viim3"],

            # Fotoperiood
            "Päevapikkus": ["Päevapikkus"],
            "Päevapikkuse trend": ["Päevapikkus", "Päevapikkus Δ7p"],
            "Kasvuperioodi päevapikkus": ["Päevapikkus kasvukesk"],
            "Päevapikkus viim3": ["Päevapikkus viim3", "Päevapikkus Δ7p"],
        }
        biological_load_candidate_groups = {
            "Ebatavaline koormus -1": ["Koormusindeks -1", "Ülekoormus -1"],
            "Kahe korje koormus": ["2 korje koormus"],
            "Tipukorje järelmõju": ["Tipukorje -1", "Tipukorje -2"],
        }
        operational_candidate_groups = {**weather_candidate_groups, **biological_load_candidate_groups}
        memory_diagnostic_groups = {
            "Eelmine A+B+C": ["Eelmine ABC"],
            "A+B+C trend 2 korjet": ["Eelmine ABC", "Eelmine2 ABC", "ABC trend"],
            "Korjejääk / kõrge eelkorje": ["Eelmine saak", "XL -1", "XL -2", "XL osakaal -1", "XL osakaal -2"],
            "XL osakaal 2 korjet": ["XL osakaal -1", "XL osakaal -2"],
        }
        diagnostic_only_groups = {
            **memory_diagnostic_groups,
            "C/B mälu 2 korjet (diagnostika)": ["C/B -1", "C/B -2"],
        }

        def _walk_forward_with_extra(extra_cols, alpha=10.0):
            raw_extra = model_df[extra_cols].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=float)
            preds = np.full(len(model_df), np.nan, dtype=float)
            for test_day in sorted(set(dates)):
                test_idx = np.where(dates == test_day)[0]
                train_idx = np.where(dates < test_day)[0]
                if len(train_idx) < min_train_rows:
                    continue
                # Kandidaat saab ainult need lisatunnused, mis tema grupis on nimetatud.
                # Eelmist saaki ei lisata enam vaikimisi ühelegi kandidaadile.
                extra_arrays = [raw_extra[:, j] for j in range(raw_extra.shape[1])]
                preds[test_idx] = _abc_growth_walk_predict(extra_arrays, train_idx, test_idx)
            return preds

        def _stability_stats(candidate_pred):
            mask = np.isfinite(predictions) & np.isfinite(candidate_pred)
            idx = np.where(mask)[0]
            if len(idx) == 0:
                return None
            base_abs = np.abs(predictions[idx] - y[idx])
            cand_abs = np.abs(candidate_pred[idx] - y[idx])
            base_mae = float(base_abs.mean())
            cand_mae = float(cand_abs.mean())
            improvement = base_mae - cand_mae
            win_share = float(np.mean(cand_abs < base_abs))
            # Ajalise stabiilsuse kontroll: sama testipäeva põllud jäävad alati samasse poolde.
            unique_test_days = sorted(set(dates[idx]))
            day_halves = np.array_split(np.array(unique_test_days, dtype=object), 2)
            half_improvements = []
            for day_half in day_halves:
                day_set = set(day_half.tolist())
                h = np.array([i for i in idx if dates[i] in day_set], dtype=int)
                if len(h) == 0:
                    continue
                half_improvements.append(float(
                    np.mean(np.abs(predictions[h] - y[h])) - np.mean(np.abs(candidate_pred[h] - y[h]))
                ))
            min_half = min(half_improvements) if half_improvements else -999.0
            stable = bool(len(idx) >= 12 and improvement >= 0.10 and win_share >= 0.50 and min_half >= -0.05)
            return {
                "Baas MAE": base_mae, "Katse MAE": cand_mae, "Paranemine": improvement,
                "Võidab ridu %": win_share * 100.0, "Halvim pool": min_half,
                "Testiridu": int(len(idx)), "Stabiilne": stable,
            }

        trace_results = []
        candidate_predictions = {}
        for name, cols in {**operational_candidate_groups, **diagnostic_only_groups}.items():
            cp = _walk_forward_with_extra(cols)
            candidate_predictions[name] = cp
            stats = _stability_stats(cp)
            if stats:
                trace_results.append({"Jälg": name, **stats})

        trace_df = pd.DataFrame(trace_results)
        if not trace_df.empty:
            trace_df = trace_df.sort_values(["Stabiilne", "Paranemine"], ascending=[False, False])

        champion_name = "Baasmudel"
        champion_cols = []
        champion_pred = predictions.copy()
        champion_mae = current_test_mae
        stable_operational = []
        for name, cols in operational_candidate_groups.items():
            if name not in candidate_predictions:
                continue
            stats = _stability_stats(candidate_predictions[name])
            if stats and stats["Stabiilne"]:
                stable_operational.append((stats["Katse MAE"], name, cols, candidate_predictions[name], stats))
        if stable_operational:
            stable_operational.sort(key=lambda x: x[0])
            champion_mae, champion_name, champion_cols, champion_pred, champion_stats = stable_operational[0]
        else:
            champion_stats = None

        st.markdown("##### Tänane champion-mootor")
        ch1, ch2, ch3 = st.columns(3)
        ch1.metric("Champion", champion_name)
        ch2.metric("A+B+C MAE", "—" if champion_mae is None else f"{champion_mae:.2f} kasti")
        if champion_stats:
            ch3.metric("Eelis baasi ees", f"{champion_stats['Paranemine']:+.2f} kasti")
            st.success(
                f"9 päeva prognoos kasutab automaatselt championit **{champion_name}**. "
                f"See võitis {champion_stats['Võidab ridu %']:.0f}% samadest testiridadest ja "
                f"parandas MAE-d {champion_stats['Paranemine']:.2f} kasti. "
                "Champion vaadatakse iga uue korjega uuesti üle."
            )
        else:
            ch3.metric("Eelis baasi ees", "0.00 kasti")
            st.info(
                "Ükski ilmast ega bioloogilisest koormusest tuletatud lisajälg ei läbinud täna stabiilsuslävendit. "
                "9 päeva prognoos kasutab seetõttu puhast ilma + intervalli + hooaja faasi + põllu baasmudelit. "
                "Toorest eelmist saaki, saagitrendi, XL-i ega C/B-d Jäljeotsija prognoosi ankruks ei luba."
            )

        # -------------------------------------------------------------------------
        # C/B kvaliteedimootor — eraldi champion, ei mõjuta A+B+C championit
        # -------------------------------------------------------------------------
        st.markdown("##### C/B kvaliteedimootor")
        st.caption(
            "C/B prognoositakse eraldi. Baasmudel kasutab korjeintervalli, ilma ja eelmist usaldusväärset C/B suhet. "
            "Jäljeotsija võib lisada ainult ajaliselt stabiilselt kasulikke tunnuseid."
        )

        valid_cb_base = np.isfinite(cb_predictions) & np.isfinite(y_cb)
        cb_base_mae = float(np.mean(np.abs(cb_predictions[valid_cb_base] - y_cb[valid_cb_base]))) if valid_cb_base.any() else None

        cb_candidate_groups = {
            "C/B mälu 2 korjet": ["C/B -2"],
            "A+B+C trend": ["Eelmine2 ABC", "ABC trend"],
            "XL / korjejääk": ["XL -1", "XL -2", "XL osakaal -1", "XL osakaal -2"],
            "Viimase 1 päeva ilm": ["T viim1", "Rad viim1", "Sade viim1", "ET0 viim1", "Niiskus viim1"],
            "Viimase 2 päeva ilm": ["T viim2", "Rad viim2", "Sade viim2", "ET0 viim2", "Niiskus viim2"],
            "Viimase 3 päeva ilm": ["T viim3", "Rad viim3", "Sade viim3", "ET0 viim3", "Niiskus viim3"],
        }

        def _cb_walk_with_extra(extra_cols, alpha=10.0):
            raw_extra = model_df[extra_cols].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=float) if extra_cols else np.empty((len(model_df), 0))
            preds = np.full(len(model_df), np.nan, dtype=float)
            for test_day in sorted(set(dates)):
                test_idx = np.where(dates == test_day)[0]
                train_idx = np.where((dates < test_day) & np.isfinite(log_y_cb))[0]
                if len(train_idx) < min_train_rows:
                    continue
                extra_arrays = [raw_cb1] + [raw_extra[:, j] for j in range(raw_extra.shape[1])]
                log_pred = _ridge_walk_predict(log_y_cb, extra_arrays, train_idx, test_idx, alpha=alpha, floor_zero=False)
                preds[test_idx] = np.exp(np.clip(log_pred, np.log(0.10), np.log(10.0)))
            return preds

        def _cb_stability_stats(candidate_pred):
            mask = np.isfinite(cb_predictions) & np.isfinite(candidate_pred) & np.isfinite(y_cb)
            idx = np.where(mask)[0]
            if len(idx) == 0:
                return None
            base_abs = np.abs(cb_predictions[idx] - y_cb[idx])
            cand_abs = np.abs(candidate_pred[idx] - y_cb[idx])
            improvement = float(base_abs.mean() - cand_abs.mean())
            win_share = float(np.mean(cand_abs < base_abs))
            unique_days = sorted(set(dates[idx]))
            halves = np.array_split(np.array(unique_days, dtype=object), 2)
            half_improvements = []
            for half in halves:
                day_set = set(half.tolist())
                h = np.array([i for i in idx if dates[i] in day_set], dtype=int)
                if len(h):
                    half_improvements.append(float(
                        np.mean(np.abs(cb_predictions[h] - y_cb[h])) - np.mean(np.abs(candidate_pred[h] - y_cb[h]))
                    ))
            min_half = min(half_improvements) if half_improvements else -999.0
            stable = bool(len(idx) >= 12 and improvement >= 0.05 and win_share >= 0.50 and min_half >= -0.03)
            return {
                "Baas MAE": float(base_abs.mean()), "Katse MAE": float(cand_abs.mean()),
                "Paranemine": improvement, "Võidab ridu %": win_share * 100.0,
                "Halvim pool": min_half, "Testiridu": int(len(idx)), "Stabiilne": stable,
            }

        cb_candidate_predictions = {}
        cb_trace_rows = []
        for name, cols in cb_candidate_groups.items():
            pred = _cb_walk_with_extra(cols)
            cb_candidate_predictions[name] = pred
            stats = _cb_stability_stats(pred)
            if stats:
                cb_trace_rows.append({"Jälg": name, **stats})

        cb_champion_name = "C/B baasmudel"
        cb_champion_cols = []
        cb_champion_mae = cb_base_mae
        cb_champion_stats = None
        cb_stable = []
        for name, cols in cb_candidate_groups.items():
            stats = _cb_stability_stats(cb_candidate_predictions.get(name)) if name in cb_candidate_predictions else None
            if stats and stats["Stabiilne"]:
                cb_stable.append((stats["Katse MAE"], name, cols, stats))
        if cb_stable:
            cb_stable.sort(key=lambda x: x[0])
            cb_champion_mae, cb_champion_name, cb_champion_cols, cb_champion_stats = cb_stable[0]

        cb1, cb2, cb3 = st.columns(3)
        cb1.metric("C/B champion", cb_champion_name)
        cb2.metric("C/B MAE", "—" if cb_champion_mae is None else f"{cb_champion_mae:.2f}")
        cb_test_rows = int(valid_cb_base.sum())
        cb_test_days = len(set(dates[np.where(valid_cb_base)[0]])) if valid_cb_base.any() else 0
        cb3.metric("Testitud", f"{cb_test_rows}/{len(model_df)} rida")
        st.caption(f"C/B aus test hõlmab {cb_test_days} testipäeva. Madalam MAE on parem.")
        if cb_champion_stats:
            st.success(
                f"C/B prognoos kasutab **{cb_champion_name}**: MAE paranemine {cb_champion_stats['Paranemine']:.2f}, "
                f"võitis {cb_champion_stats['Võidab ridu %']:.0f}% samadest testiridadest."
            )
        else:
            st.info("Ükski C/B lisajälg ei läbinud stabiilsuslävendit; kvaliteediprognoos kasutab C/B baasmudelit.")

        if cb_trace_rows:
            with st.expander("Näita C/B jäljeotsija tulemusi"):
                cb_trace_df = pd.DataFrame(cb_trace_rows).sort_values(["Stabiilne", "Paranemine"], ascending=[False, False])
                st.dataframe(cb_trace_df.style.format({
                    "Baas MAE": "{:.2f}", "Katse MAE": "{:.2f}", "Paranemine": "{:+.2f}",
                    "Võidab ridu %": "{:.0f}%", "Halvim pool": "{:+.2f}",
                }), use_container_width=True, hide_index=True)

        def _fit_full_generic(target, extra_arrays, alpha=10.0, field_alpha=80.0):
            idx = np.where(np.isfinite(target))[0]
            Xtr, _, means, scales, fills = _build_ridge_design(idx, idx, extra_arrays)
            penalty = np.eye(Xtr.shape[1]) * alpha
            penalty[0, 0] = 0.0
            # Partial pooling põldudele: 14 viimast koefitsienti saavad tugevama
            # regulaaristuse kui ilma/hooaja tunnused. Nii ei õpi 2–3 korjerea põhjal
            # mõne põllu jaoks kunstlikku suurt negatiivset/positiivset püsiefekti.
            penalty[-14:, -14:] = np.eye(14) * field_alpha
            beta = np.linalg.pinv(Xtr.T @ Xtr + penalty) @ Xtr.T @ target
            return {"beta": beta, "means": means, "scales": scales, "fills": fills, "n_extra": len(extra_arrays)}

        def _predict_full_generic(model, field_no, base_values, extra_values, floor_zero=True):
            x = list(base_values)
            miss = []
            for i, value in enumerate(extra_values):
                if value is None or not np.isfinite(float(value)):
                    x.append(model["fills"][i])
                    miss.append(1.0)
                else:
                    x.append(float(value))
                    miss.append(0.0)
            x = np.array([x], dtype=float)
            z = (x - model["means"]) / model["scales"]
            onehot = np.zeros((1, 14), dtype=float)
            if 1 <= int(field_no) <= 14:
                onehot[0, int(field_no) - 1] = 1.0
            Xp = np.column_stack([np.ones(1), z, np.array([miss], dtype=float), onehot])
            value = float((Xp @ model["beta"])[0])
            return max(0.0, value) if floor_zero else value

        def _fit_full_abc_growth(extra_arrays, alpha=10.0, field_alpha=80.0, z_clip=2.5):
            idx = np.where(np.isfinite(log_y_abc))[0]
            Xtr, _, means, scales, fills = _build_ridge_design(idx, idx, extra_arrays)
            n_numeric = X_base.shape[1] + len(extra_arrays)
            Xtr[:, 1:1+n_numeric] = np.clip(Xtr[:, 1:1+n_numeric], -z_clip, z_clip)
            penalty = np.eye(Xtr.shape[1]) * alpha
            penalty[0, 0] = 0.0
            penalty[-14:, -14:] = np.eye(14) * field_alpha
            beta = np.linalg.pinv(Xtr.T @ Xtr + penalty) @ Xtr.T @ log_y_abc[idx]
            return {
                "beta": beta, "means": means, "scales": scales, "fills": fills,
                "n_extra": len(extra_arrays), "z_clip": z_clip,
            }

        def _predict_full_abc_growth(model, field_no, base_values, extra_values):
            x = list(base_values)
            miss = []
            for i, value in enumerate(extra_values):
                try:
                    finite_value = value is not None and np.isfinite(float(value))
                except (TypeError, ValueError):
                    finite_value = False
                if not finite_value:
                    x.append(model["fills"][i])
                    miss.append(1.0)
                else:
                    x.append(float(value))
                    miss.append(0.0)
            x = np.array([x], dtype=float)
            z = (x - model["means"]) / model["scales"]
            z = np.clip(z, -model.get("z_clip", 2.5), model.get("z_clip", 2.5))
            onehot = np.zeros((1, 14), dtype=float)
            if 1 <= int(field_no) <= 14:
                onehot[0, int(field_no) - 1] = 1.0
            Xp = np.column_stack([np.ones(1), z, np.array([miss], dtype=float), onehot])
            latent = float((Xp @ model["beta"])[0])
            return float(np.exp(np.clip(latent, np.log(ABC_LOG_EPS), 6.0)))

        def _abc_growth_explain(model, field_no, base_values, extra_values, extra_names):
            """Jaga V6.4 log-mudeli prognoos täpselt +/- kastipanusteks.

            Referents on mudeli neutraalne treeningtase: standardiseeritud pidevad tunnused = 0,
            puuduvad lisatunnused = 0 ja põlluefekt = 0. Kuna exp() on mittelineaarne,
            skaleerime latentse lineaarse panuse ühiselt tagasi kastiskaalale. Nii kehtib:
            mudelibaas + kõigi tegurite panused = A+B+C prognoos.
            """
            x = list(base_values)
            miss = []
            for i, value in enumerate(extra_values):
                try:
                    finite_value = value is not None and np.isfinite(float(value))
                except (TypeError, ValueError):
                    finite_value = False
                if not finite_value:
                    x.append(model["fills"][i])
                    miss.append(1.0)
                else:
                    x.append(float(value))
                    miss.append(0.0)

            x = np.array(x, dtype=float)
            z = (x - model["means"]) / model["scales"]
            z = np.clip(z, -model.get("z_clip", 2.5), model.get("z_clip", 2.5))

            beta = model["beta"]
            n_base = len(base_cont_cols)
            n_extra = len(extra_values)
            groups = {
                "Temperatuur": 0.0, "Radiatsioon": 0.0, "Sademed": 0.0,
                "Niiskus": 0.0, "ET0": 0.0, "Tuul": 0.0, "Tuul+stress": 0.0,
                "Päevapikkus": 0.0,
                "Intervall": 0.0, "Hooaeg": 0.0, "Põlluefekt": 0.0,
                "Biokoormus": 0.0, "Muu": 0.0,
            }

            def _group_for_feature(name):
                if name == "Intervall p":
                    return "Intervall"
                if name == "Hooajapäev":
                    return "Hooaeg"
                if (
                    name in {"T kesk", "Tmin kesk", "Tmax kesk", "Tmin min", "Tmax max"}
                    or str(name).startswith(("T viim", "Tmin viim", "Tmax viim", "Öö ", "Päeva "))
                ):
                    return "Temperatuur"
                if str(name).startswith("Radiatsioon") or str(name).startswith("Rad viim"):
                    return "Radiatsioon"
                if str(name).startswith("Sademed") or str(name).startswith("Sade viim"):
                    return "Sademed"
                if str(name).startswith("Niiskus"):
                    return "Niiskus"
                if str(name).startswith("ET0"):
                    return "ET0"
                if str(name).startswith("Päevapikkus"):
                    return "Päevapikkus"
                if str(name).startswith("Tuul×"):
                    return "Tuul+stress"
                if str(name).startswith("Tuul"):
                    return "Tuul"
                if name in {"Koormusindeks -1", "Ülekoormus -1", "2 korje koormus", "Tipukorje -1", "Tipukorje -2"}:
                    return "Biokoormus"
                return "Muu"

            numeric_names = list(base_cont_cols) + list(extra_names)
            for j, name in enumerate(numeric_names):
                groups[_group_for_feature(name)] += float(beta[1 + j] * z[j])

            # Lisatunnuste missing-indikaatorid kuuluvad sama teguri panuse sisse.
            miss_start = 1 + len(numeric_names)
            for j, name in enumerate(extra_names):
                groups[_group_for_feature(name)] += float(beta[miss_start + j] * miss[j])

            field_start = miss_start + n_extra
            if 1 <= int(field_no) <= 14:
                groups["Põlluefekt"] += float(beta[field_start + int(field_no) - 1])

            intercept = float(beta[0])
            latent_delta = float(sum(groups.values()))
            latent = intercept + latent_delta
            pred = float(np.exp(np.clip(latent, np.log(ABC_LOG_EPS), 6.0)))
            baseline = float(np.exp(np.clip(intercept, np.log(ABC_LOG_EPS), 6.0)))

            # Monotoonse exp() korral on see ühine positiivne skaalategur.
            # Panused säilitavad märgi ja summeeruvad täpselt prognoosini.
            if abs(latent_delta) > 1e-12:
                scale = (pred - baseline) / latent_delta
                crate_effects = {k: float(v * scale) for k, v in groups.items()}
            else:
                crate_effects = {k: 0.0 for k in groups}

            return {
                "baseline": baseline,
                "effects": crate_effects,
                "reconstructed": baseline + sum(crate_effects.values()),
                "prediction": pred,
            }

        champion_extra_arrays = [
            pd.to_numeric(model_df[c], errors="coerce").to_numpy(dtype=float) for c in champion_cols
        ]
        full_abc_base_model = _fit_full_abc_growth([])
        full_abc_model = _fit_full_abc_growth(champion_extra_arrays)
        biological_load_feature_names = {
            c for cols in biological_load_candidate_groups.values() for c in cols
        }
        champion_uses_biological_load = any(c in biological_load_feature_names for c in champion_cols)
        full_xl_model = _fit_full_generic(y_xl, [raw_xl1, raw_xl2, raw_prev_abc, raw_prev_total])
        cb_champion_extra_arrays = [
            pd.to_numeric(model_df[c], errors="coerce").to_numpy(dtype=float) for c in cb_champion_cols
        ]
        full_cb_model = _fit_full_generic(log_y_cb, [raw_cb1] + cb_champion_extra_arrays)

        # -------------------------------------------------------------------------
        # 9 päeva ette: A+B+C + eraldi XL
        # -------------------------------------------------------------------------
        st.markdown("##### 9 päeva saagiprognoos")
        st.caption(
            f"A+B+C kasutab tänast champion-mootorit: {champion_name}. Baasmudel põhineb ilmal, intervallil, "
            f"hooaja faasil ja põllu identiteedil. Tõestatud normaliseeritud bioloogiline koormus võib baasi korrigeerida, "
            f"kuid toores eelmine saak, saagitrend ja muud korjeajaloo mälutunnused ei saa prognoosi ankurdada. "
            f"C/B kasutab eraldi championit: {cb_champion_name}. XL lisatakse eraldi korjejäägi komponendina. "
            "Korjevahemiku möödunud päevadel kasutatakse mõõdetud ilma ja tulevastel päevadel 9 päeva ilmaprognoosi. "
            "Põllu eripära on mudelis partial-pooling kujul: väikese põllupõhise valimi korral ei lasta põlluefektil ilma mõju üle sõita."
        )
        st.info(
            "Oluline: ajalooline walk-forward MAE mõõdab saagimudelit realiseerunud mõõdetud ilma peal. "
            "Päris 1–9 päeva prognoos sisaldab lisaks ilmaprognoosi viga. Operatiivset täpsust hakkame mõõtma "
            "yield_forecasts snapshot'ide põhjal, kui tegelikud korjed saabuvad."
        )

        future_weather_end = TODAY + timedelta(days=9)
        all_weather_rows = db.get_weather_rows(readiness_start, future_weather_end)
        all_weather_by_day = {str(r.get("weather_date")): r for r in all_weather_rows}
        weather_feature_names = [
            "temp_min_c", "temp_max_c", "wind_avg_ms", "radiation_mj_m2",
            "humidity_avg_pct", "precipitation_mm", "et0_mm",
        ]

        def _nearest_weather_value(day_value, feature):
            """Ajutine fallback ainult mudeli arvutuseks.

            Minevikupäeva puuduvat väärtust ei täideta tuleviku prognoosiga.
            Kasutame kuni kolme lähima VARASEMA päeva olemasolevaid väärtusi.
            Nii saab 3 päeva ilmasisend jätkuda ka siis, kui ametlik Pärnu päev
            saabub osaliselt. UI märgib sellise päeva hinnanguliseks.
            """
            candidates = []
            for delta in range(1, 4):
                dd = day_value - timedelta(days=delta)
                row = all_weather_by_day.get(dd.isoformat())
                if row and row.get(feature) is not None:
                    try:
                        candidates.append(float(row.get(feature)))
                    except (TypeError, ValueError):
                        pass
            return float(np.mean(candidates)) if candidates else None

        def _weather_window_for_prediction(previous_day, target_day):
            rows, estimated_days = [], set()
            d = previous_day + timedelta(days=1)
            while d <= target_day:
                src = all_weather_by_day.get(d.isoformat())
                if not src:
                    return None, None
                clean = {}
                for feature in weather_feature_names:
                    value = src.get(feature)
                    try:
                        value = float(value) if value is not None else None
                    except (TypeError, ValueError):
                        value = None
                    if value is None:
                        value = _nearest_weather_value(d, feature)
                        if value is not None:
                            estimated_days.add(d)
                    if value is None:
                        return None, None
                    clean[feature] = value
                rows.append(clean)
                d += timedelta(days=1)
            if not rows:
                return None, None
            tmins_all = [r["temp_min_c"] for r in rows]
            tmaxs_all = [r["temp_max_c"] for r in rows]
            mean_t = [(lo + hi) / 2 for lo, hi in zip(tmins_all, tmaxs_all)]
            wx = {
                "Intervall p": (target_day - previous_day).days,
                "Hooajapäev": (target_day - date(2026, 7, 1)).days,
                "T kesk": float(np.mean(mean_t)),
                "Tmin kesk": float(np.mean(tmins_all)),
                "Tmax kesk": float(np.mean(tmaxs_all)),
                "Tmin min": float(np.min(tmins_all)),
                "Tmax max": float(np.max(tmaxs_all)),
                "Soojad ööd 16+": int(sum(1 for v in tmins_all if v >= 16.0)),
                "Soojad ööd 18+": int(sum(1 for v in tmins_all if v >= 18.0)),
                "Jahedad ööd 12-": int(sum(1 for v in tmins_all if v <= 12.0)),
                "Soojad ööd 16+ %": 100.0 * sum(1 for v in tmins_all if v >= 16.0) / len(tmins_all),
                "Soojad ööd 18+ %": 100.0 * sum(1 for v in tmins_all if v >= 18.0) / len(tmins_all),
                "Jahedad ööd 12- %": 100.0 * sum(1 for v in tmins_all if v <= 12.0) / len(tmins_all),
                "Radiatsioon Σ": float(np.sum([r["radiation_mj_m2"] for r in rows])),
                "Radiatsioon/p": float(np.mean([r["radiation_mj_m2"] for r in rows])),
                "Sademed Σ": float(np.sum([r["precipitation_mm"] for r in rows])),
                "Niiskus kesk": float(np.mean([r["humidity_avg_pct"] for r in rows])),
                "ET0 Σ": float(np.sum([r["et0_mm"] for r in rows])),
                "Tuul kesk": float(np.mean([r["wind_avg_ms"] for r in rows])),
                "Päevapikkus": _daylength_hours(target_day),
                "Päevapikkus Δ7p": _daylength_change_7d(target_day),
                "Päevapikkus kasvukesk": float(np.mean([
                    _daylength_hours(previous_day + timedelta(days=i))
                    for i in range(1, (target_day - previous_day).days + 1)
                ])) if (target_day - previous_day).days > 0 else _daylength_hours(target_day),
            }

            # Sama tuule koostoime arvutus peab olema õppimisel ja prognoosis identne.
            # Täpselt sama mittelineaarne temperatuuribaas nagu õppimisandmestikus.
            wx.update(_temperature_curve_features(tmins_all, tmaxs_all))

            wx["Tuul×Tmax"] = wx["Tuul kesk"] * wx["Tmax kesk"]
            wx["Tuul×Rad/p"] = wx["Tuul kesk"] * wx["Radiatsioon/p"]
            wx["Tuul×ET0/p"] = wx["Tuul kesk"] * (wx["ET0 Σ"] / max(1, len(rows)))
            wx["Tuul×Kuivus"] = wx["Tuul kesk"] * (100.0 - wx["Niiskus kesk"])
            for n in (1, 2, 3):
                tail = rows[-min(n, len(rows)):]
                tmins = [r["temp_min_c"] for r in tail]
                tmaxs = [r["temp_max_c"] for r in tail]
                tvals = [(lo + hi) / 2 for lo, hi in zip(tmins, tmaxs)]
                wx[f"T viim{n}"] = float(np.mean(tvals))
                wx[f"Tmin viim{n}"] = float(np.mean(tmins))
                wx[f"Tmax viim{n}"] = float(np.mean(tmaxs))
                wx[f"Rad viim{n}"] = float(np.sum([r["radiation_mj_m2"] for r in tail]))
                wx[f"Sade viim{n}"] = float(np.sum([r["precipitation_mm"] for r in tail]))
                wx[f"ET0 viim{n}"] = float(np.sum([r["et0_mm"] for r in tail]))
                wx[f"Niiskus viim{n}"] = float(np.mean([r["humidity_avg_pct"] for r in tail]))
                wx[f"Tuul viim{n}"] = float(np.mean([r["wind_avg_ms"] for r in tail]))
                wx[f"Tuul×Tmax viim{n}"] = wx[f"Tuul viim{n}"] * wx[f"Tmax viim{n}"]
                wx[f"Tuul×Rad/p viim{n}"] = wx[f"Tuul viim{n}"] * (wx[f"Rad viim{n}"] / len(tail))
                wx[f"Tuul×ET0/p viim{n}"] = wx[f"Tuul viim{n}"] * (wx[f"ET0 viim{n}"] / len(tail))
                wx[f"Tuul×Kuivus viim{n}"] = wx[f"Tuul viim{n}"] * (100.0 - wx[f"Niiskus viim{n}"])
                wx[f"Päevapikkus viim{n}"] = float(np.mean([
                    _daylength_hours(target_day - timedelta(days=i))
                    for i in range(min(n, len(rows)))
                ]))
            return wx, estimated_days

        def _champion_feature_values(state, wx):
            values = {
                # Toored saagimälu väärtused on siin ainult diagnostika ühilduvuse jaoks;
                # operatiivse championi nimekiri neid ei sisalda.
                "Eelmine ABC": state.get("abc"),
                "Eelmine2 ABC": state.get("abc_prev"),
                "ABC trend": (state.get("abc") - state.get("abc_prev")) if state.get("abc") is not None and state.get("abc_prev") is not None else None,
                "Eelmine saak": state.get("total"),
                "XL -1": state.get("xl"),
                "XL -2": state.get("xl_prev"),
                "XL osakaal -1": (state.get("xl") / state.get("total")) if state.get("xl") is not None and state.get("total") not in (None, 0) else None,
                "XL osakaal -2": (state.get("xl_prev") / state.get("total_prev")) if state.get("xl_prev") is not None and state.get("total_prev") not in (None, 0) else None,
                "Koormusindeks -1": state.get("load_index"),
                "Ülekoormus -1": state.get("overload"),
                "2 korje koormus": state.get("load2_index"),
                "Tipukorje -1": state.get("peak"),
                "Tipukorje -2": state.get("peak_prev"),
            }
            for k, v in wx.items():
                if (
                    k.startswith((
                        "T viim", "Tmin viim", "Tmax viim", "Rad viim", "Sade viim",
                        "ET0 viim", "Niiskus viim", "Tuul viim", "Tuul×"
                    ))
                    or k in {
                        "Tmin min", "Tmax max", "Soojad ööd 16+ %",
                        "Soojad ööd 18+ %", "Jahedad ööd 12- %",
                        "Tuul×Tmax", "Tuul×Rad/p", "Tuul×ET0/p", "Tuul×Kuivus",
                        "Päevapikkus", "Päevapikkus Δ7p", "Päevapikkus kasvukesk"
                    }
                    or k.startswith("Päevapikkus viim")
                ):
                    values[k] = v
            return [values.get(c) for c in champion_cols]

        def _cb_champion_feature_values(state, wx):
            values = {
                "C/B -2": state.get("cb_prev"),
                "Eelmine2 ABC": state.get("abc_prev"),
                "ABC trend": (state.get("abc") - state.get("abc_prev")) if state.get("abc") is not None and state.get("abc_prev") is not None else None,
                "XL -1": state.get("xl"),
                "XL -2": state.get("xl_prev"),
                "XL osakaal -1": (state.get("xl") / state.get("total")) if state.get("xl") is not None and state.get("total") not in (None, 0) else None,
                "XL osakaal -2": (state.get("xl_prev") / state.get("total_prev")) if state.get("xl_prev") is not None and state.get("total_prev") not in (None, 0) else None,
            }
            for k, v in wx.items():
                if (
                    k.startswith((
                        "T viim", "Tmin viim", "Tmax viim", "Rad viim", "Sade viim",
                        "ET0 viim", "Niiskus viim", "Tuul viim", "Tuul×"
                    ))
                    or k in {
                        "Tmin min", "Tmax max", "Soojad ööd 16+ %",
                        "Soojad ööd 18+ %", "Jahedad ööd 12- %",
                        "Tuul×Tmax", "Tuul×Rad/p", "Tuul×ET0/p", "Tuul×Kuivus",
                        "Päevapikkus", "Päevapikkus Δ7p", "Päevapikkus kasvukesk"
                    }
                    or k.startswith("Päevapikkus viim")
                ):
                    values[k] = v
            return [values.get(c) for c in cb_champion_cols]

        def _predict_one(field_no, state, target_day):
            wx, estimated_days = _weather_window_for_prediction(state["date"], target_day)
            if wx is None:
                return None
            base_values = [wx[c] for c in base_cont_cols]
            # Bioloogilise koormuse korrektsioon on lubatud ainult siis, kui sihtkorje
            # eelmine sama põllu korje on päriselt mõõdetud. Kui vahepealne eelkorje on
            # ise tulevikuprognoos, ei toida me mudelit tema enda väljundiga tagasi.
            if champion_uses_biological_load and state.get("source") != "tegelik":
                # Sama põld võib 9 päeva aknas tulla uuesti korjesse. Prognoositud eelkorjet
                # ei kasutata järgmise korje biokoormuse sisendina.
                abc_extra_values = [None for _ in champion_cols]
                abc_mode = f"{champion_name} · koormus neutraalne"
            else:
                abc_extra_values = _champion_feature_values(state, wx)
                abc_mode = champion_name

            abc_pred = _predict_full_abc_growth(
                full_abc_model, field_no, base_values, abc_extra_values,
            )
            abc_explain = _abc_growth_explain(
                full_abc_model, field_no, base_values, abc_extra_values, champion_cols,
            )
            xl_pred = _predict_full_generic(
                full_xl_model, field_no, base_values,
                [state.get("xl"), state.get("xl_prev"), state.get("abc"), state.get("total")],
            )
            cb_log_pred = _predict_full_generic(
                full_cb_model, field_no, base_values,
                [state.get("cb")] + _cb_champion_feature_values(state, wx),
                floor_zero=False,
            )
            cb_pred = float(np.exp(np.clip(cb_log_pred, np.log(0.10), np.log(10.0))))
            return {
                "abc": abc_pred, "xl": xl_pred, "cb": cb_pred, "total": abc_pred + xl_pred,
                "interval": wx["Intervall p"], "estimated_days": estimated_days or set(), "abc_mode": abc_mode,
                "abc_explain": abc_explain, "wx": wx,
            }

        field_state = {}
        field_actual_abc_hist = {}
        field_peak_hist = {}
        for row in sorted(harvest_rows, key=lambda r: (str(r.get("harvest_date") or ""), int(r.get("harvest_order") or 99))):
            try:
                d = date.fromisoformat(str(row.get("harvest_date")))
                f = int(row.get("field_no"))
                a = float(row.get("a")); b = float(row.get("b")); c = float(row.get("c")); xl = float(row.get("xl"))
                total_value = float(row.get("total"))
            except (TypeError, ValueError):
                continue
            if d < TODAY:
                quality = str(row.get("data_quality") or "").strip().lower()
                old = field_state.get(f)
                abc_value = a + b + c
                hist = field_actual_abc_hist.setdefault(f, [])
                peak_hist = field_peak_hist.setdefault(f, [])
                prior = hist[-3:]
                baseline = float(np.mean(prior)) if prior else None
                load_index = (abc_value / baseline) if (baseline is not None and baseline > 0) else None
                overload = max(0.0, load_index - 1.0) if load_index is not None else None
                load2_index = None
                if prior:
                    load2_index = (float(np.mean([abc_value, prior[-1]])) / baseline) if baseline > 0 else None
                peak = 1.0 if (load_index is not None and load_index >= 1.25) else 0.0 if load_index is not None else None
                field_state[f] = {
                    "date": d, "abc": abc_value,
                    "abc_prev": old.get("abc") if old else None,
                    "xl": xl, "xl_prev": old.get("xl") if old else None,
                    "cb": (c / b) if b > 0 else None, "cb_prev": old.get("cb") if old else None,
                    "total": total_value, "total_prev": old.get("total") if old else None,
                    "load_index": load_index, "overload": overload, "load2_index": load2_index,
                    "peak": peak, "peak_prev": peak_hist[-1] if peak_hist else None,
                    "source": "tegelik",
                }
                if quality not in {"hinnanguline", "ligikaudne"}:
                    hist.append(abc_value)
                    peak_hist.append(peak)

        today_rows_live = db.get_harvest_for_day(TODAY)
        today_plan_default = _planned_fields_for_day(TODAY, today_rows_live, harvest_rows)

        # Avalehel võib kasutaja tänase 3 põllu valikust ühe eemaldada.
        # Kui sessionis pole valikut, kasutame automaatset plaani.
        selected_home = st.session_state.get("home_today_fields")
        if selected_home is not None:
            today_plan = [int(f) for f in list(selected_home)[:4]]
        else:
            today_plan = [int(f) for f in today_plan_default]

        today_actual = {int(r.get("field_no")): r for r in today_rows_live if r.get("field_no") is not None}

        # Tänane prognoos arvutatakse kõigile valitud põldudele ENNE tänaste
        # tegelike ridade rakendamist. Nii saab avalehel võrrelda prognoosi ja tegelikku.
        today_forecast_rows = []
        today_predictions_by_field = {}
        for f in today_plan:
            prev = field_state.get(int(f))
            if not prev:
                continue
            pred = _predict_one(int(f), prev, TODAY)
            if not pred:
                continue
            today_predictions_by_field[int(f)] = pred
            today_forecast_rows.append({
                "Põld": int(f),
                "A+B+C": pred["abc"],
                "C/B": pred["cb"],
                "XL": pred["xl"],
                "Kokku": pred["total"],
                "Intervall": pred["interval"],
                "Hinnanguline ilm": ", ".join(sorted(d.strftime("%d.%m") for d in pred["estimated_days"])) or "—",
            })

        internal_today = []
        for f in today_plan:
            actual = today_actual.get(int(f))
            if actual:
                try:
                    old = field_state.get(int(f))
                    a=float(actual.get("a")); b=float(actual.get("b")); c=float(actual.get("c")); xl=float(actual.get("xl")); total=float(actual.get("total"))
                    abc_value = a + b + c
                    hist = field_actual_abc_hist.setdefault(int(f), [])
                    peak_hist = field_peak_hist.setdefault(int(f), [])
                    prior = hist[-3:]
                    baseline = float(np.mean(prior)) if prior else None
                    load_index = (abc_value / baseline) if (baseline is not None and baseline > 0) else None
                    overload = max(0.0, load_index - 1.0) if load_index is not None else None
                    load2_index = (float(np.mean([abc_value, prior[-1]])) / baseline) if (prior and baseline and baseline > 0) else None
                    peak = 1.0 if (load_index is not None and load_index >= 1.25) else 0.0 if load_index is not None else None
                    field_state[int(f)] = {
                        "date": TODAY, "abc": abc_value,
                        "abc_prev": old.get("abc") if old else None,
                        "xl": xl, "xl_prev": old.get("xl") if old else None,
                        "cb": (c / b) if b > 0 else None, "cb_prev": old.get("cb") if old else None,
                        "total": total, "total_prev": old.get("total") if old else None,
                        "load_index": load_index, "overload": overload, "load2_index": load2_index,
                        "peak": peak, "peak_prev": peak_hist[-1] if peak_hist else None,
                        "source": "tegelik",
                    }
                    hist.append(abc_value); peak_hist.append(peak)
                    continue
                except (TypeError, ValueError):
                    pass

            prev = field_state.get(int(f))
            pred = today_predictions_by_field.get(int(f))
            if not prev or not pred:
                continue
            field_state[int(f)] = {
                "date": TODAY, "abc": pred["abc"], "abc_prev": prev.get("abc"),
                "xl": pred["xl"], "xl_prev": prev.get("xl"),
                "cb": pred["cb"], "cb_prev": prev.get("cb"),
                "total": pred["total"], "total_prev": prev.get("total"),
                "load_index": None, "overload": None, "load2_index": None,
                "peak": None, "peak_prev": prev.get("peak"),
                "source": "prognoos",
            }
            internal_today.append((int(f), pred["total"]))

        forecast_days = []
        first_field = _next_field(today_plan[-1]) if today_plan else 1
        current_first = first_field
        any_weather_imputation = set()
        for offset in range(1, 10):
            target_day = TODAY + timedelta(days=offset)
            day_fields = [current_first, _next_field(current_first), _next_field(_next_field(current_first))]
            day_rows = []
            for f in day_fields:
                prev = field_state.get(int(f))
                if not prev:
                    day_rows.append({"Põld": f, "A+B+C": None, "C/B": None, "XL": None, "Kokku": None, "Intervall": None, "Alus": "puudub", "Hinnanguline ilm": "—"})
                    continue
                result = _predict_one(int(f), prev, target_day)
                if not result:
                    day_rows.append({"Põld": f, "A+B+C": None, "C/B": None, "XL": None, "Kokku": None, "Intervall": (target_day-prev["date"]).days, "Alus": prev["source"], "Hinnanguline ilm": "puudub"})
                    continue
                any_weather_imputation.update(result["estimated_days"])
                source_label = "tegelik eelkorje" if prev["source"] == "tegelik" else "prognoositud eelkorje"
                if result.get("abc_mode") == "weather-first fallback":
                    source_label += " · ABC weather-first fallback"
                day_rows.append({
                    "Põld": f, "A+B+C": result["abc"], "C/B": result["cb"], "XL": result["xl"], "Kokku": result["total"],
                    "Intervall": result["interval"], "Alus": source_label,
                    "Hinnanguline ilm": ", ".join(sorted(d.strftime("%d.%m") for d in result["estimated_days"])) or "—",
                    "_ABC_selgitus": result.get("abc_explain"), "_WX": result.get("wx"),
                })
                field_state[int(f)] = {
                    "date": target_day, "abc": result["abc"], "abc_prev": prev.get("abc"),
                    "xl": result["xl"], "xl_prev": prev.get("xl"),
                    "cb": result["cb"], "cb_prev": prev.get("cb"),
                    "total": result["total"], "total_prev": prev.get("total"),
                    "load_index": None, "overload": None, "load2_index": None,
                    "peak": None, "peak_prev": prev.get("peak"),
                    "source": "prognoos",
                }
            forecast_days.append((target_day, day_rows))
            current_first = _next_field(day_fields[-1])

        # Salvestame 9 päeva prognoosid eraldi ajalukku. Sama päeva rerun uuendab
        # olemasolevat snapshot'i; järgmine päev loob uue lead-time snapshot'i.
        # Mudeliversioon tähistab champion-valiku raamistikku, mitte tänase võitja nime.
        # Nii uuendab sama päeva rerun sama operatiivset snapshot'i ka siis, kui champion
        # uue korje järel päeva jooksul muutub. Võitja nimi salvestub basis-väljale.
        MODEL_VERSION = "v6.4-growth-nonlinear-temp-nights-wind-daylength-v5"
        forecast_payloads = []

        # Salvesta ka tänase päeva prognoos lead=0 snapshotina.
        # See võimaldab hiljem näha, kuhu 5p/3p/1p/täna prognoos korjepäeva lähenedes liikus.
        for row in today_forecast_rows:
            if row.get("A+B+C") is None or row.get("XL") is None or row.get("Kokku") is None:
                continue
            forecast_payloads.append({
                "forecast_date": TODAY.isoformat(),
                "target_date": TODAY.isoformat(),
                "field_no": int(row["Põld"]),
                "lead_days": 0,
                "abc_forecast": float(row["A+B+C"]),
                "cb_forecast": float(row["C/B"]) if row.get("C/B") is not None else None,
                "xl_forecast": float(row["XL"]),
                "total_forecast": float(row["Kokku"]),
                "interval_days": row.get("Intervall"),
                "basis": f"tänane tööprognoos; champion={champion_name}; cb_champion={cb_champion_name}",
                "estimated_weather_days": row.get("Hinnanguline ilm") or "",
                "model_version": MODEL_VERSION,
            })

        for target_day, rows_day in forecast_days:
            for row in rows_day:
                if row.get("A+B+C") is None or row.get("XL") is None or row.get("Kokku") is None:
                    continue
                forecast_payloads.append({
                    "forecast_date": TODAY.isoformat(),
                    "target_date": target_day.isoformat(),
                    "field_no": int(row["Põld"]),
                    "lead_days": (target_day - TODAY).days,
                    "abc_forecast": float(row["A+B+C"]),
                    "cb_forecast": float(row["C/B"]) if row.get("C/B") is not None else None,
                    "xl_forecast": float(row["XL"]),
                    "total_forecast": float(row["Kokku"]),
                    "interval_days": row.get("Intervall"),
                    "basis": f"{row.get('Alus') or ''}; champion={champion_name}; cb_champion={cb_champion_name}",
                    "estimated_weather_days": row.get("Hinnanguline ilm") or "",
                    "model_version": MODEL_VERSION,
                })

        forecast_store_ok = False
        try:
            if db.yield_forecasts_available():
                db.save_yield_forecasts(forecast_payloads)
                forecast_store_ok = True
            else:
                st.warning("Prognoosid arvutatakse, kuid neid ei salvestata veel: Supabase'is puudub yield_forecasts tabel. Käivita ZIP-is olev supabase_yield_forecasts.sql üks kord.")
        except db.DatabaseError as exc:
            st.warning(f"Prognoosid arvutatakse, kuid ajaloo salvestamine ebaõnnestus: {exc}")

        # Prognoosi liikumine: esimene sama korjepäeva snapshot vs praegune prognoos.
        # Kasutame ainult sama põllukomplekti täielikke snapshot'e.
        forecast_history_rows = []
        try:
            if db.yield_forecasts_available():
                forecast_history_rows = db.get_yield_forecasts(limit=5000)
        except db.DatabaseError:
            forecast_history_rows = []

        def _forecast_adjustment(target_day_value, field_numbers, current_total):
            expected = {int(f) for f in field_numbers}
            if not expected or current_total is None:
                return None, None, None

            # Kui sama forecast_date/field kohta on mitu model_version rida,
            # eelista kõige hiljem genereeritut.
            picked = {}
            for hist in forecast_history_rows:
                if str(hist.get("target_date")) != target_day_value.isoformat():
                    continue
                try:
                    fno = int(hist.get("field_no"))
                except (TypeError, ValueError):
                    continue
                if fno not in expected:
                    continue
                fdate = str(hist.get("forecast_date") or "")
                key = (fdate, fno)
                old_hist = picked.get(key)
                if old_hist is None or str(hist.get("generated_at") or "") > str(old_hist.get("generated_at") or ""):
                    picked[key] = hist

            by_date = {}
            for (fdate, fno), hist in picked.items():
                by_date.setdefault(fdate, {})[fno] = hist

            complete = []
            for fdate, rows_for_date in by_date.items():
                if set(rows_for_date.keys()) != expected:
                    continue
                try:
                    total = sum(float(rows_for_date[f]["total_forecast"]) for f in expected)
                except (TypeError, ValueError, KeyError):
                    continue
                complete.append((fdate, total))

            if not complete:
                return None, None, None

            complete.sort(key=lambda x: x[0])
            first_date, first_total = complete[0]
            if first_total <= 0:
                return None, first_total, first_date

            pct = (float(current_total) / first_total - 1.0) * 100.0
            return pct, first_total, first_date

        # --- Avalehe kiire ülevaade ---
        try:
            selected_set = {int(f) for f in today_plan}
            actual_rows_home = [
                r for r in today_rows_live
                if int(r.get("field_no") or 0) in selected_set
            ]
            actual_sum = _daily_summary(actual_rows_home) if actual_rows_home else {
                "total": 0.0, "a": 0.0, "b": 0.0, "c": 0.0, "xl": 0.0, "cb": None
            }
            actual_cb_text = "—" if actual_sum["cb"] is None else _fmt(actual_sum["cb"], 2)
            actual_complete = bool(today_plan) and len(actual_rows_home) == len(today_plan)
            actual_error_text = ""
            # today_total_fc is computed below; use direct sum from today's forecast rows here.
            today_fc_for_error = sum(
                float(r["Kokku"]) for r in today_forecast_rows if r.get("Kokku") is not None
            ) if today_forecast_rows else None
            if actual_complete and actual_sum["total"] > 0 and today_fc_for_error is not None:
                forecast_error_pct = (today_fc_for_error / float(actual_sum["total"]) - 1.0) * 100.0
                actual_error_text = f" · prognoosiviga {forecast_error_pct:+.0f}%"

            with home_today_actual_slot.container():
                st.markdown(
                    f"""
                    <div style="border:1px solid rgba(128,128,128,.25);border-radius:12px;padding:12px 14px;">
                      <div style="font-size:.80rem;font-weight:900;letter-spacing:.10em;opacity:.58;">TEGELIK</div>
                      <div style="font-size:2.15rem;font-weight:900;line-height:1.05;margin-top:3px;">{_fmt(actual_sum['total'])} kasti</div>
                      <div style="font-size:.92rem;opacity:.74;margin-top:6px;">
                        A {_fmt(actual_sum['a'])} · B {_fmt(actual_sum['b'])} · C {_fmt(actual_sum['c'])} · XL {_fmt(actual_sum['xl'])} · C/B {actual_cb_text}{actual_error_text}
                      </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

            today_vals = [r for r in today_forecast_rows if r.get("Kokku") is not None]
            if today_vals:
                today_total_fc = sum(float(r["Kokku"]) for r in today_vals)
                today_abc_fc = sum(float(r["A+B+C"]) for r in today_vals if r.get("A+B+C") is not None)
                today_xl_fc = sum(float(r["XL"]) for r in today_vals if r.get("XL") is not None)
                today_cb_vals = [float(r["C/B"]) for r in today_vals if r.get("C/B") is not None]
                today_cb_fc = float(np.mean(today_cb_vals)) if today_cb_vals else None
                cb_fc_text = "—" if today_cb_fc is None else _fmt(today_cb_fc, 2)
                today_adjust_pct, today_first_fc, today_first_date = _forecast_adjustment(
                    TODAY,
                    [r["Põld"] for r in today_vals],
                    today_total_fc,
                )
                if today_adjust_pct is None:
                    today_adjust_text = "kohendus —"
                else:
                    today_adjust_text = f"kohendus {today_adjust_pct:+.0f}%"

                with home_today_forecast_slot.container():
                    st.markdown(
                        f"""
                        <div style="border:2px solid rgba(76,160,92,.38);border-radius:12px;padding:12px 14px;">
                          <div style="font-size:.80rem;font-weight:900;letter-spacing:.10em;opacity:.58;">PROGNOOS</div>
                          <div style="display:flex;justify-content:space-between;gap:10px;align-items:baseline;margin-top:3px;">
                            <div style="font-size:2.15rem;font-weight:950;line-height:1.05;">{_fmt(today_total_fc)} kasti</div>
                            <div style="font-size:1.02rem;font-weight:800;opacity:.76;">{today_adjust_text}</div>
                          </div>
                          <div style="font-size:.92rem;opacity:.76;margin-top:6px;">
                            A+B+C {_fmt(today_abc_fc)} · XL {_fmt(today_xl_fc)} · C/B ~{cb_fc_text}
                          </div>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )
            else:
                with home_today_forecast_slot.container():
                    st.info("Tänast prognoosi ei saanud moodustada.")

            engine_parts = [
                f"A+B+C mootor: {champion_name}",
                "XL eraldi",
                f"C/B mootor: {cb_champion_name}",
            ]
            engine_parts.append("ilm osaliselt hinnanguline" if any_weather_imputation else "ilm täielik")
            if champion_uses_biological_load:
                engine_parts.append("biokoormus kasutusel")
            with home_engine_info_slot.container():
                st.caption(" · ".join(engine_parts))

            with home_future_forecast_slot.container():
                for target_day, rows_day in forecast_days:
                    valid = [r for r in rows_day if r.get("Kokku") is not None]
                    if not valid:
                        continue
                    total_day = sum(float(r["Kokku"]) for r in valid)
                    abc_day = sum(float(r["A+B+C"]) for r in valid if r.get("A+B+C") is not None)
                    xl_day = sum(float(r["XL"]) for r in valid if r.get("XL") is not None)
                    cb_vals = [float(r["C/B"]) for r in valid if r.get("C/B") is not None]
                    cb_day = float(np.mean(cb_vals)) if cb_vals else None
                    cb_text = "—" if cb_day is None else _fmt(cb_day, 2)
                    lead = (target_day - TODAY).days
                    field_numbers_day = [int(r["Põld"]) for r in valid]
                    adj_pct, first_fc_total, first_fc_date = _forecast_adjustment(
                        target_day, field_numbers_day, total_day
                    )
                    adj_text = "kohendus —" if adj_pct is None else f"kohendus {adj_pct:+.0f}%"
                    trend = lead >= 6
                    bg = "#fff3cd" if trend else "rgba(0,0,0,0.025)"
                    border = "#ffe69c" if trend else "rgba(128,128,128,0.20)"
                    badge = f" · 🟡 trend {lead} p" if trend else ""
                    st.markdown(
                        f"""
                        <div style="background:{bg};border:1px solid {border};border-radius:10px;
                                    padding:10px 12px;margin:7px 0;">
                          <div style="display:flex;justify-content:space-between;gap:12px;align-items:center;">
                            <div style="display:flex;align-items:center;gap:10px;">
                              <span style="font-size:1.65rem;font-weight:950;opacity:.38;">{_weekday_letter(target_day)}</span>
                              <strong style="font-size:1.05rem;">{_short_date(target_day)}</strong>
                            </div>
                            <strong style="font-size:1.15rem;">{_fmt(total_day)} kasti · {adj_text}{badge}</strong>
                          </div>
                          <div style="font-size:0.90rem;opacity:0.78;margin-top:3px;">
                            A+B+C {_fmt(abc_day)} · XL {_fmt(xl_day)} · C/B ~{cb_text}
                          </div>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )
        except Exception as exc:
            with home_today_forecast_slot.container():
                st.caption(f"Avalehe prognoosivaade ei laadunud: {exc}")

        if internal_today:
            st.caption("Tänase poolelioleva korje sisemine tööprognoos: " + ", ".join(f"põld {f} ≈ {p:.1f}" for f,p in internal_today) + ". Tegelik kirje asendab selle automaatselt.")
        if any_weather_imputation:
            st.warning("⚠️ Mudeli arvutuses täideti puuduva ilma väärtusi ajutiselt kuni 3 varasema päeva keskmisega: " + ", ".join(sorted(d.strftime("%d.%m") for d in any_weather_imputation)) + ". Ilma ajaloo tabelis jäävad mõõdetud andmed muutmata.")

        for target_day, rows_day in forecast_days:
            vals = [r["Kokku"] for r in rows_day if r["Kokku"] is not None]
            total_day = sum(vals) if len(vals) == 3 else None
            total_text = f"{_fmt(total_day)} kasti" if total_day is not None else "prognoos puudulik"
            lead = (target_day - TODAY).days
            if lead >= 6:
                header_html = (
                    '<div style="background:#fff3cd;border:1px solid #ffe69c;border-radius:10px;'
                    'padding:8px 12px;margin:12px 0 6px 0;">'
                    f'<span style="font-size:1.45rem;font-weight:700;">{_short_date(target_day)}&emsp;&emsp;{total_text}</span>'
                    f'<span style="margin-left:10px;font-size:0.92rem;">🟡 trendiprognoos · {lead} p ette</span>'
                    '</div>'
                )
                st.markdown(header_html, unsafe_allow_html=True)
            else:
                confidence = "kõrgem kindlus" if lead <= 3 else "keskmine kindlus"
                st.markdown(f"### {_short_date(target_day)}  {total_text}")
                st.caption(f"{lead} p ette · {confidence}")
            day_df = pd.DataFrame(rows_day)
            visible_cols = [c for c in day_df.columns if not str(c).startswith("_")]
            day_df_visible = day_df[visible_cols]
            st.dataframe(day_df_visible.style.format({
                "A+B+C": lambda v: "—" if pd.isna(v) else f"{float(v):.1f}",
                "C/B": lambda v: "—" if pd.isna(v) else f"{float(v):.2f}",
                "XL": lambda v: "—" if pd.isna(v) else f"{float(v):.1f}",
                "Kokku": lambda v: "—" if pd.isna(v) else f"{float(v):.1f}",
                "Intervall": lambda v: "—" if pd.isna(v) else f"{int(v)} p",
            }), use_container_width=True, hide_index=True)

            explain_rows = []
            input_lines = []
            for r in rows_day:
                ex = r.get("_ABC_selgitus")
                wxr = r.get("_WX") or {}
                if not ex:
                    continue
                effects = ex.get("effects") or {}
                erow = {
                    "Põld": r.get("Põld"),
                    "Mudelibaas": ex.get("baseline"),
                    "Temperatuur": effects.get("Temperatuur", 0.0),
                    "Radiatsioon": effects.get("Radiatsioon", 0.0),
                    "Sademed": effects.get("Sademed", 0.0),
                    "Niiskus": effects.get("Niiskus", 0.0),
                    "ET0": effects.get("ET0", 0.0),
                    "Tuul": effects.get("Tuul", 0.0),
                    "Intervall": effects.get("Intervall", 0.0),
                    "Hooaeg": effects.get("Hooaeg", 0.0),
                    "Põlluefekt": effects.get("Põlluefekt", 0.0),
                    "Biokoormus": effects.get("Biokoormus", 0.0),
                    "A+B+C": ex.get("prediction"),
                }
                if abs(float(effects.get("Muu", 0.0) or 0.0)) >= 0.01:
                    erow["Muu"] = effects.get("Muu", 0.0)
                explain_rows.append(erow)
                try:
                    input_lines.append(
                        f"põld {int(r.get('Põld'))}: Tmin {float(wxr.get('Tmin kesk')):.1f} °C (min {float(wxr.get('Tmin min')):.1f}) · "
                        f"Tmax {float(wxr.get('Tmax kesk')):.1f} °C (max {float(wxr.get('Tmax max')):.1f}) · "
                        f"sooje öid ≥16 °C {int(wxr.get('Soojad ööd 16+'))}/{int(wxr.get('Intervall p'))} · "
                        f"päev {float(wxr.get('Päevapikkus')):.2f} h ({float(wxr.get('Päevapikkus Δ7p')):+.2f} h/7p) · "
                        f"rad {float(wxr.get('Radiatsioon Σ')):.1f} MJ/m² ({float(wxr.get('Radiatsioon/p')):.1f}/p) · "
                        f"sade {float(wxr.get('Sademed Σ')):.1f} mm · RH {float(wxr.get('Niiskus kesk')):.0f}% · "
                        f"ET0 {float(wxr.get('ET0 Σ')):.1f} mm · intervall {int(wxr.get('Intervall p'))} p"
                    )
                except (TypeError, ValueError):
                    pass

            if explain_rows:
                st.caption("A+B+C selgitus · +/− = teguri panus kastides võrreldes mudeli neutraalse treeningtasemega")
                explain_df = pd.DataFrame(explain_rows)
                effect_cols = [c for c in explain_df.columns if c not in {"Põld", "Mudelibaas", "A+B+C"}]
                fmt = {
                    "Mudelibaas": lambda v: "—" if pd.isna(v) else f"{float(v):.1f}",
                    "A+B+C": lambda v: "—" if pd.isna(v) else f"{float(v):.1f}",
                }
                for c in effect_cols:
                    fmt[c] = lambda v: "—" if pd.isna(v) else f"{float(v):+.1f}"
                st.dataframe(explain_df.style.format(fmt), use_container_width=True, hide_index=True)
                if input_lines:
                    st.caption("Sisendid · " + "  |  ".join(input_lines))

        abc_mae_text = f"{current_test_mae:.1f} kasti/põld" if current_test_mae is not None else "veel hindamata"
        total_mae_text = f"{current_total_test_mae:.1f} kasti/põld" if current_total_test_mae is not None else "veel hindamata"
        st.caption(
            f"A+B+C ajaline testviga: {abc_mae_text}. Kogusaagi (ABC+XL) testviga: {total_mae_text}. "
            f"1–3 päeva on operatiivne vaade, 4–5 päeva planeerimisvaade ja 6–9 päeva kollasega märgitud trendiprognoos. "
            "A+B+C prognoosi baas on weather-first. Tõestatud bioloogiline koormus võib korrigeerida ainult siis, kui eelkorje on päriselt mõõdetud; "
            "prognoositud eelkorjet ei kasutata koormuse tagasisidena. Kaugematel päevadel kasvab ebakindlus eelkõige ilmaprognoosi tõttu."
        )

        # -------------------------------------------------------------------------
        # Salvestatud prognoos vs tegelik
        # -------------------------------------------------------------------------
        if forecast_store_ok:
            st.markdown("##### Prognooside ajalugu")
            st.caption("Iga päev jääb alles uus 1–9 päeva ette tehtud snapshot. Tegelik korje liidetakse kuvamisel automaatselt harvests tabelist.")
            try:
                saved_forecasts_all = db.get_yield_forecasts(limit=1000)
                saved_forecasts = [r for r in saved_forecasts_all if str(r.get("model_version") or "") == MODEL_VERSION]
            except db.DatabaseError:
                saved_forecasts_all = []
                saved_forecasts = []
            actual_lookup = {}
            for hr in harvest_rows:
                try:
                    key = (str(hr.get("harvest_date")), int(hr.get("field_no")))
                    a = float(hr.get("a")); b = float(hr.get("b")); c = float(hr.get("c")); xl = float(hr.get("xl")); total = float(hr.get("total"))
                    actual_lookup[key] = {"abc": a+b+c, "cb": (c/b) if b > 0 else None, "xl": xl, "total": total}
                except (TypeError, ValueError):
                    continue

            history_rows = []
            for fr in saved_forecasts:
                if str(fr.get("model_version")) != MODEL_VERSION:
                    continue
                key = (str(fr.get("target_date")), int(fr.get("field_no")))
                actual = actual_lookup.get(key)
                try:
                    abc_f = float(fr.get("abc_forecast")); xl_f = float(fr.get("xl_forecast")); total_f = float(fr.get("total_forecast"))
                except (TypeError, ValueError):
                    continue
                history_rows.append({
                    "Prognoositud": str(fr.get("forecast_date")),
                    "Korjepäev": str(fr.get("target_date")),
                    "Põld": int(fr.get("field_no")),
                    "Ette": int(fr.get("lead_days") or 0),
                    "ABC prognoos": abc_f,
                    "C/B prognoos": float(fr.get("cb_forecast")) if fr.get("cb_forecast") is not None else None,
                    "XL prognoos": xl_f,
                    "Kokku prognoos": total_f,
                    "ABC tegelik": actual.get("abc") if actual else None,
                    "C/B tegelik": actual.get("cb") if actual else None,
                    "XL tegelik": actual.get("xl") if actual else None,
                    "Kokku tegelik": actual.get("total") if actual else None,
                    "Kogu viga": (total_f - actual["total"]) if actual else None,
                })
            hist_df = pd.DataFrame(history_rows)
            if not hist_df.empty:
                matured = hist_df[pd.notna(hist_df["Kokku tegelik"])].copy()
                if not matured.empty:
                    hm1, hm2, hm3, hm4 = st.columns(4)
                    abs_err = matured["Kogu viga"].abs()
                    hm1.metric("Pärisprognoose hinnatud", len(matured))
                    hm2.metric("MAE", f"{abs_err.mean():.1f} kasti")
                    hm3.metric("±2 sees", f"{(abs_err <= 2).mean()*100:.0f}%")
                    one_day = matured[matured["Ette"] == 1]
                    hm4.metric("1 p MAE", "—" if one_day.empty else f"{one_day['Kogu viga'].abs().mean():.1f} kasti")
                hist_show = hist_df.sort_values(["Korjepäev", "Põld", "Ette"], ascending=[False, True, True]).head(120).copy()
                for dc in ("Prognoositud", "Korjepäev"):
                    hist_show[dc] = hist_show[dc].map(lambda x: date.fromisoformat(x).strftime("%d.%m") if x else "—")
                st.dataframe(
                    hist_show.style.format({
                        "Ette": lambda v: f"{int(v)} p",
                        "ABC prognoos": "{:.1f}", "C/B prognoos": lambda v: "—" if pd.isna(v) else f"{v:.2f}", "XL prognoos": "{:.1f}", "Kokku prognoos": "{:.1f}",
                        "ABC tegelik": lambda v: "—" if pd.isna(v) else f"{v:.1f}",
                        "C/B tegelik": lambda v: "—" if pd.isna(v) else f"{v:.2f}",
                        "XL tegelik": lambda v: "—" if pd.isna(v) else f"{v:.1f}",
                        "Kokku tegelik": lambda v: "—" if pd.isna(v) else f"{v:.1f}",
                        "Kogu viga": lambda v: "—" if pd.isna(v) else f"{v:+.1f}",
                    }),
                    use_container_width=True, hide_index=True,
                )
            else:
                st.caption("Esimesed prognoosisnapshot'id salvestatakse nüüd. Tegelike korjete lisandudes tekib siia võrdlus.")

        # -------------------------------------------------------------------------
        # Jäljeotsija — uurimisraport päriselt tehtud testide põhjal
        # -------------------------------------------------------------------------
        if valid_pred.any():
            st.markdown("##### Jäljeotsija — tänane uurimisraport")
            st.caption(
                "Kõik allolevad väited tulevad samast ajaliselt ausast walk-forward testist. "
                "Jäljeotsija ei lisa tunnust mootorisse pelgalt hea ühe tulemuse pärast: kasu peab olema piisav ja ajaliselt stabiilne."
            )

            if not trace_df.empty:
                # Inimloetavad hüpoteesid. Need ei ole järeldused, vaid kirjeldavad, mida test päriselt proovis.
                trace_hypotheses = {
                    "Eelmine A+B+C": "kas eelmise korje A+B+C annab ilma ja kasvudünaamika kõrval veel lisainfot",
                    "A+B+C trend 2 korjet": "kas kahe viimase korje saagisuund annab järgmise korje kohta lisasignaali",
                    "Korjejääk / kõrge eelkorje": "kas kõrge eelkorje koos XL-jäljega viitab vahele jäänud viljale või järelmõjule",
                    "XL osakaal 2 korjet": "kas XL osakaalu mälu kannab järgmisse korjesse kasutatavat signaali",
                    "Ebatavaline koormus -1": "kas eelmise korje ebatavaliselt suur A+B+C võrreldes sama põllu varasema tasemega jätab järgmisse korjesse taastumisefekti",
                    "Kahe korje koormus": "kas kahe järjestikuse korje keskmisest suurem koormus vähendab järgmise korje potentsiaali",
                    "Tipukorje järelmõju": "kas selge tipukorje mõju avaldub 1–2 korjet hiljem, mitte toore eelmise saagi ankurdusena",
                    "Viimase 1 päeva ilm": "kas korje-eelse viimase päeva ilm on tähtsam kui kogu korjevahemiku keskmine",
                    "Viimase 2 päeva ilm": "kas korje-eelse kahe päeva ilm annab eraldi lisasignaali",
                    "Viimase 3 päeva ilm": "kas korje-eelse kolme päeva ilm annab eraldi lisasignaali",
                    "C/B mälu 2 korjet (diagnostika)": "kas varasem suurusjaotus kannab järgmise korje A+B+C kohta diagnostilist infot",
                }

                def _why_not_stable(row):
                    reasons = []
                    if int(row.get("Testiridu", 0)) < 12:
                        reasons.append("testiridu on veel vähe")
                    if float(row.get("Paranemine", 0.0)) < 0.10:
                        reasons.append("MAE paranemine on alla 0,10 kasti")
                    if float(row.get("Võidab ridu %", 0.0)) < 50.0:
                        reasons.append("ei võida vähemalt pooli testiridu")
                    if float(row.get("Halvim pool", -999.0)) < -0.05:
                        reasons.append("mõju ei püsi testi mõlemas ajapooles")
                    return ", ".join(reasons) if reasons else "ei läbinud stabiilsusreeglit"

                operational_trace = trace_df[trace_df["Jälg"].isin(operational_candidate_groups.keys())].copy()
                operational_trace = operational_trace.sort_values("Paranemine", ascending=False)
                memory_trace = trace_df[trace_df["Jälg"].isin(memory_diagnostic_groups.keys())].copy()
                memory_trace = memory_trace.sort_values("Paranemine", ascending=False)

                st.markdown("**Mida ma täna kaalusin**")
                considered = []
                for _, r in trace_df.sort_values("Paranemine", ascending=False).iterrows():
                    name = r["Jälg"]
                    role = ("weather-first kandidaat" if name in weather_candidate_groups else
                            "bioloogilise koormuse kandidaat" if name in biological_load_candidate_groups else
                            "uurimisjälg (ei juhi prognoosi)")
                    considered.append(f"**{name}** — {trace_hypotheses.get(name, 'lisatunnuse võimalik mõju')} · {role}")
                if considered:
                    st.markdown(";  ".join(considered) + ".")

                st.markdown("**Praegu parim mootor**")
                if champion_stats:
                    st.success(
                        f"**{champion_name}** on tänane champion. Samadel testiridadel on MAE "
                        f"{champion_stats['Katse MAE']:.2f} kasti võrreldes baasi {champion_stats['Baas MAE']:.2f}-ga "
                        f"(paranemine {champion_stats['Paranemine']:.2f}). See võitis "
                        f"{champion_stats['Võidab ridu %']:.0f}% testiridadest ja mõju püsis ajaliselt piisavalt stabiilne."
                    )
                else:
                    st.info(
                        f"**{champion_name}** jääb championiks. Ükski lisajälg ei tõestanud täna piisavalt stabiilset eelist. "
                        f"Weather-first baasi MAE on {champion_mae:.2f} kasti."
                    )

                if not memory_trace.empty:
                    best_memory = memory_trace.iloc[0]
                    st.markdown("**Tugevaim ajalooline mälusignaal (ainult uurimiseks)**")
                    direction = "parandas" if float(best_memory["Paranemine"]) > 0 else "ei parandanud"
                    st.write(
                        f"**{best_memory['Jälg']}** {direction} samadel testiridadel MAE-d "
                        f"{best_memory['Paranemine']:+.2f} kasti ja võitis {best_memory['Võidab ridu %']:.0f}% ridadest. "
                        "Seda ei kasutata A+B+C operatiivse championina isegi siis, kui ajalooline sobivus on hea, "
                        "sest järsu ilmamuutuse korral peab prognoosi juhtima kasvuilm, mitte eelmise korje tase."
                    )

                # Lähim kandidaat = parima paranemisega lubatud (ilm või bioloogiline koormus) kandidaat, mis pole champion.
                nearest = None
                for _, r in operational_trace.iterrows():
                    if r["Jälg"] != champion_name:
                        nearest = r
                        break
                if nearest is not None:
                    st.markdown("**Lähim kandidaat**")
                    name = nearest["Jälg"]
                    if bool(nearest["Stabiilne"]):
                        status_text = "läbis stabiilsusreegli, kuid jäi tänasele championile alla"
                    else:
                        status_text = _why_not_stable(nearest)
                    st.write(
                        f"**{name}**: MAE {nearest['Katse MAE']:.2f} vs baas {nearest['Baas MAE']:.2f}; "
                        f"muutus {nearest['Paranemine']:+.2f} kasti, võitis {nearest['Võidab ridu %']:.0f}% ridadest. "
                        f"Praegu ei tõsta ma seda championiks, sest {status_text}."
                    )

                watch = trace_df[(trace_df["Paranemine"] > 0) & (~trace_df["Stabiilne"])].sort_values("Paranemine", ascending=False).head(4)
                if not watch.empty:
                    st.markdown("**Hoian silma peal**")
                    for _, r in watch.iterrows():
                        role = ("weather-first kandidaat" if r["Jälg"] in weather_candidate_groups else
                                "bioloogilise koormuse kandidaat" if r["Jälg"] in biological_load_candidate_groups else
                                "uurimisjälg")
                        st.write(
                            f"• **{r['Jälg']}** ({role}) — praegu {r['Paranemine']:+.2f} kasti MAE muutus; "
                            f"{_why_not_stable(r)}. Uute korjetega kontrollin seda uuesti."
                        )

                rejected = trace_df[trace_df["Paranemine"] <= 0].sort_values("Paranemine", ascending=False).head(5)
                if not rejected.empty:
                    st.markdown("**Praegu kõrvale jäetud**")
                    for _, r in rejected.iterrows():
                        st.write(
                            f"• **{r['Jälg']}** — ei parandanud tänases testis baasi "
                            f"(MAE muutus {r['Paranemine']:+.2f} kasti). See ei tähenda, et seost kindlasti pole; "
                            "praegused andmed ei toeta selle kasutamist championis."
                        )

                with st.expander("Näita Jäljeotsija kõiki teste ja numbreid"):
                    show_trace = trace_df.copy()
                    st.dataframe(
                        show_trace.style.format({
                            "Baas MAE": "{:.2f}", "Katse MAE": "{:.2f}", "Paranemine": "{:+.2f}",
                            "Võidab ridu %": "{:.0f}%", "Halvim pool": "{:+.2f}",
                        }),
                        use_container_width=True, hide_index=True,
                    )
                    st.caption(
                        f"Aktiivne A+B+C champion: {champion_name}. Valik arvutatakse uuesti iga uue korje järel. "
                        "Toored saagimälu tunnused on raportis diagnostilised; normaliseeritud bioloogiline koormus võib championiks saada ainult stabiilse tõendi korral. "
                        "Toortabel on alles kontrolliks; põhiinfo on ülal uurimisraportis."
                    )
    else:
        st.info("Täieliku ilmavahemiku ja numbrilise saagiga õppimisridu ei ole veel piisavalt.")

    st.markdown("##### Mida mudel hiljem sellest kasutab")
    st.write(
        "Põhimudeli õppimisnäite siht on konkreetse põllu järgmise korje A+B+C. XL õpitakse eraldi korjejäägi komponendina. Sisenditesse saab ilmavahemikust "
        "arvutada näiteks temperatuuri, radiatsiooni, sademete, õhuniiskuse ja ET0 summad/keskmised ning "
        "korjeintervalli. Toores eelmine saak ei ole prognoosi sisendankur; ainult sellest tuletatud ja walk-forward testiga tõestatud bioloogiline koormus võib weather-first baasi korrigeerida."
    )

    if last_complete_harvest and latest_harvest and latest_harvest > last_complete_harvest:
        st.caption(
            "Uuem pooleliolev korjepäev jääb õppimisest ajutiselt välja, kuni päeva korjeplokk on täielik."
        )

    st.divider()
    st.info("Mudel töötab kihiliselt: weather-first A+B+C baas + ainult tõestatud bioloogilise koormuse korrektsioon + eraldi XL ja C/B komponendid. Toores eelmine saak ei ole prognoosi ankur ega champion-tunnus.")

with tabs[4]:
    st.subheader("Mootori tähelepanekud")
    st.info("Mootor hakkab hiljem mustreid kuvama, kuid ei muuda mudelit ise.")
